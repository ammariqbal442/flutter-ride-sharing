import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:juber_car_booking/admin-panel/AdminSelectRidedriver.dart';
import 'package:juber_car_booking/admin-panel/components/AdminDrawerComponent.dart';
import 'package:juber_car_booking/screens/JCBSelectRidedriver.dart';
import 'package:nb_utils/nb_utils.dart';

import 'package:juber_car_booking/utils/JCBConstants.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:juber_car_booking/main.dart';
import 'dart:async';

final GlobalKey<ScaffoldState> jcbHomeKey = GlobalKey();

// ignore: must_be_immutable
class AdminHomeScreen extends StatefulWidget {

  static const CameraPosition initialCameraPosition = CameraPosition(target: LatLng(37.42796133580664, -122.085749655962), zoom: 14);  

  @override
  State<AdminHomeScreen> createState() => _AdminHomeScreenState();
}

class _AdminHomeScreenState extends State<AdminHomeScreen> {
   late GoogleMapController googleMapController;

GoogleMapController? mapController;

 Set<Marker> markers = {};

  // declaration of dropdownmenu items
    String location = "Search Location";

    String googleApikey = "AIzaSyAmAiqgDzdYHdWpY_JwrXtICmIhnNT6AsM";

// bool _isLoading = false;

//   @override
//   void initState() {
//     super.initState();
//     // Simulating some asynchronous task
//     Future.delayed(Duration(seconds: 10), () {
//       setState(() {
//         _isLoading = false;
//       });
//       // Navigate to the new page
//       Navigator.pushReplacement(
        
//         context,
//         MaterialPageRoute(builder: (context) => AdminSelectRidedriver()),
//       );
//     });
//   }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: jcbHomeKey,
      drawer: AdminDrawerComponent(),
      body: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          
 GoogleMap(
        initialCameraPosition: AdminHomeScreen.initialCameraPosition,
        markers: markers,
      
        zoomControlsEnabled: true,
        
        mapType: MapType.normal,
        onMapCreated: (GoogleMapController controller) {
          googleMapController = controller;
        },
      ),
      
           Container(
            decoration: BoxDecoration(
                color: Colors.black87, borderRadius: radiusOnly(topLeft: jcbBottomSheetRadius, topRight: jcbBottomSheetRadius)),
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
               
         Container(
                  padding: EdgeInsets.only(left: 16),
                  decoration: BoxDecoration(
                    borderRadius: radius(jcbButtonRadius),
                    border: Border.all(color: Colors.red),
                    color: Colors.red
                  ),
                  child: 
            Padding(
                    padding: const EdgeInsets.only(left: 100),
                    child: 
                 AppTextField(
                      autoFocus: false,
                      textFieldType: TextFieldType.NAME,
                      textStyle: boldTextStyle(),
                      onChanged: (val) {
                        hideKeyboard(context);
                  
                      },
                      onTap: () {
        Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AdminSelectRidedriver(),
              ),
            );

                        hideKeyboard(context);
                        
                        
                      },
                      decoration: InputDecoration(
                       
                        border: InputBorder.none,
                        hintText: 'Searching Rides',
                        hintStyle: boldTextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ),
                16.height,
                
              ],
            ),
          ),
          Positioned(
            left: 16,
            top: context.statusBarHeight + 16,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: radius(100),
                border: Border.all(color: context.scaffoldBackgroundColor, width: 2),
              ),
              child: Image.asset(
                'images/juberCarBooking/jcb_face2.jpg',
                height: 40,
                width: 40,
                fit: BoxFit.cover,
              ).cornerRadiusWithClipRRect(100).onTap(() {
                jcbHomeKey.currentState!.openDrawer();
              }, borderRadius: radius(100)),
            ),
          )
        ],
      ),
    );
  }
}
