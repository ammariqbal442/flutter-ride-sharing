import 'dart:async';

import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:juber_car_booking/utils/JBCColors.dart';
import 'package:juber_car_booking/utils/JCBCommon.dart';
import 'package:juber_car_booking/utils/JCBConstants.dart';
import 'package:juber_car_booking/main.dart';
import 'package:firebase_database/firebase_database.dart';

class AdminJCBReplyScreen extends StatefulWidget {
  @override
  State<AdminJCBReplyScreen> createState() => _AdminJCBReplyScreenState();
}

class _AdminJCBReplyScreenState extends State<AdminJCBReplyScreen> {
  TextEditingController reply = TextEditingController();
  List<String> repliesList = [];

  late DatabaseReference chatsRef;

  @override
  void initState() {
    super.initState();
    chatsRef = usersRef.child("chats");
    fetchChatsData();
  }

  void fetchChatsData() {
  chatsRef.once().then((DataSnapshot snapshot) {
    if (snapshot.value != null) {
      Map<dynamic, dynamic>? chats = snapshot.value as Map<dynamic, dynamic>?; // Cast snapshot.value to Map<dynamic, dynamic>?
      if (chats != null) {
        chats.forEach((key, value) {
          String userMessage = value['user_message'];
          repliesList.add(userMessage);
        });
        setState(() {});
      }
    }
  } as FutureOr Function(DatabaseEvent value)).catchError((error) {
    print('Error fetching chats data: $error');
  });
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appStore.isDarkModeOn ? context.cardColor : jcbBackGroundColor,
      appBar: AppBar(
        leading: jcbBackWidget(context),
        title: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Muhhamad Azam', style: boldTextStyle(color: appStore.isDarkModeOn ? Colors.white : jcbDarkColor)),
            Text('ST3571 - Toyoto Corola', style: secondaryTextStyle(color: jcbGreyColor, size: 10)),
          ],
        ),
        centerTitle: true,
        actions: [
          Image.asset(
            'images/juberCarBooking/pc1.png',
            height: 30,
            width: 40,
            fit: BoxFit.cover,
          ).cornerRadiusWithClipRRect(100).paddingAll(8),
        ],
        elevation: 0.5,
      ),
      body: SizedBox(
        height: context.height(),
        width: context.width(),
        child: Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  16.height,
                  if (repliesList.isNotEmpty)
                    ListView.builder(
                      itemCount: repliesList.length,
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return Align(
                          alignment: Alignment.centerRight,
                          child: Container(
                            margin: EdgeInsets.symmetric(vertical: 8),
                            padding: EdgeInsets.all(16),
                            decoration: BoxDecoration(color: jcbPrimaryColor, borderRadius: radius(jcbBottomSheetRadius)),
                            child: Text(repliesList[index], style: boldTextStyle(color: Colors.white)),
                          ),
                        );
                      },
                    )
                ],
              ).paddingAll(16),
            ),
            Positioned(
              bottom: 0,
              child: Container(
                width: context.width(),
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: context.scaffoldBackgroundColor,
                  border: Border(top: BorderSide(color: appStore.isDarkModeOn ? context.dividerColor : jcbSecBorderColor)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(
                          border: Border.all(color: appStore.isDarkModeOn ? context.dividerColor : jcbSecBorderColor),
                          borderRadius: radius(jcbButtonRadius)),
                      width: context.width() * 0.76,
                      child: AppTextField(
                        controller: reply,
                        autoFocus: false,
                        textFieldType: TextFieldType.NAME,
                        textInputAction: TextInputAction.done,
                        textStyle: boldTextStyle(),
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: 'Type a message..',
                          hintStyle: boldTextStyle(color: jcbGreyColor, size: 14),
                        ),
                        onFieldSubmitted: (val) {
                          if (val != '') {
                            repliesList.add(val);
                          // Save user data when send button pressed
                            setState(() {});
                          }
                        },
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.send, color: jcbPrimaryColor, size: 30),
                      onPressed: () {
                        hideKeyboard(context);
                        if (reply.text != '') {
                          repliesList.add(reply.text);
                       
                          reply.clear(); // Clear the text field after saving the data
                          setState(() {});
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
