import 'package:flutter/material.dart';
import 'package:juber_car_booking/components/JCBFoundDriverComponent.dart';
import 'package:juber_car_booking/components/JCBFoundDriverOnMap.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:juber_car_booking/components/JCBDrawerComponent.dart';
import 'package:juber_car_booking/screens/JCBSearchDestinationScreen.dart';
import 'package:juber_car_booking/utils/JBCColors.dart';
import 'package:juber_car_booking/utils/JCBConstants.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:juber_car_booking/main.dart';

import '../admin-panel/components/JCBFoundDriverOnMap.dart';

final GlobalKey<ScaffoldState> jcbHomeKey = GlobalKey();

// ignore: must_be_immutable
class AdminJCBTrackingDriver extends StatelessWidget {
   late GoogleMapController googleMapController;
GoogleMapController? mapController;
 Set<Marker> markers = {};
  static const CameraPosition initialCameraPosition = CameraPosition(target: LatLng(37.42796133580664, -122.085749655962), zoom: 14);


  
  // declaration of dropdownmenu items
    String? selectedValue = null;
    String location = "Search Location";
    String googleApikey = "AIzaSyAmAiqgDzdYHdWpY_JwrXtICmIhnNT6AsM";


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: jcbHomeKey,
      drawer: JCBDrawerComponent(),
      body: Stack(
        alignment: Alignment.bottomCenter,
        children: [
 GoogleMap(
        initialCameraPosition: initialCameraPosition,
        markers: markers,
      
        zoomControlsEnabled: true,
        
        mapType: MapType.normal,
        onMapCreated: (GoogleMapController controller) {
          googleMapController = controller;
        },
      ),
      
        AdminJCBFoundDriverOnMap(),
        ],
      ),
    );
  }
}
