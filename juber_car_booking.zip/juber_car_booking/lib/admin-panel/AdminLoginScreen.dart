// ignore_for_file: must_be_immutable

import 'package:firebase_auth/firebase_auth.dart';

import 'package:flutter/material.dart';

import 'package:google_sign_in/google_sign_in.dart';
import 'package:juber_car_booking/admin-panel/AdminHomeScreen.dart';
import 'package:juber_car_booking/admin-panel/AdminSignUpScreen.dart';

import 'package:nb_utils/nb_utils.dart';

import 'package:juber_car_booking/utils/JBCColors.dart';
import 'package:juber_car_booking/utils/JCBCommon.dart';
import 'package:juber_car_booking/utils/JCBConstants.dart';
import 'package:juber_car_booking/main.dart';

import '../firebase_auth/validator.dart';

class AdminLoginScreen extends StatefulWidget {
  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends State<AdminLoginScreen> {

  bool _isProcessing = false;

  TextEditingController emailCont = TextEditingController();

  TextEditingController passwordCont = TextEditingController();
   final _emailTextController = TextEditingController();
  final _passwordTextController = TextEditingController();
  GlobalKey<FormState> _adminabcKey = GlobalKey<FormState>();

final FirebaseAuth auth = FirebaseAuth.instance;
_googleSignUp() async {
    try {
      final GoogleSignIn _googleSignIn = GoogleSignIn(
        scopes: ['email'],
      );
      final FirebaseAuth _auth = FirebaseAuth.instance;

      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      final GoogleSignInAuthentication? googleAuth =
      await googleUser?.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth?.accessToken,
        idToken: googleAuth?.idToken,
      );

      final User? user = (await _auth.signInWithCredential(credential)).user;
      //print("signed in " + user.displayName);

      return user;
    } catch (e) {
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: jcbBackWidget(context),
        actions: [
          Text('Sign Up', style: boldTextStyle(color: jcbPrimaryColor)).center().paddingSymmetric(horizontal: 16).onTap(() {
            finish(context);
            AdminSignUpScreen().launch(context);
          }, splashColor: Colors.transparent, highlightColor: Colors.transparent),
        ],
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text('Log in As Driver',
                style: boldTextStyle(
                    size: 30, fontFamily: jcbFont, color: appStore.isDarkModeOn ? Colors.white : jcbDarkColor, weight: FontWeight.w900)),
                    40.height,
                    
                     SizedBox(
                        height: 120,
                        width: 120,
                        child: Image.asset("images/juberCarBooking/final.png"),
                      ),
                      Form(
                        key: _adminabcKey,
                        child: Column(
                          children: <Widget>[
                            TextFormField(
                              controller: _emailTextController,
                              //focusNode: _focusEmail,
                              validator: (value) => Validator.validateEmail(
                                email: value,
                              ),
                              decoration: InputDecoration(
                                hintText: "Email",
                                errorBorder: UnderlineInputBorder(
                                  borderRadius: BorderRadius.circular(6.0),
                                  borderSide: BorderSide(
                                    color: Colors.red,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: 8.0),
                            TextFormField(
                              controller: _passwordTextController,
                             // focusNode: _focusPassword,
                              obscureText: true,
                              validator: (value) => Validator.validatePassword(
                                password: value,
                              ),
                              decoration: InputDecoration(
                                hintText: "Password",
                                errorBorder: UnderlineInputBorder(
                                  borderRadius: BorderRadius.circular(6.0),
                                  borderSide: BorderSide(
                                    color: Colors.red,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: 24.0),
                            _isProcessing
                            ? CircularProgressIndicator()
                            : Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: ElevatedButton(
                                    onPressed: ()  {
                                                                    
                                          // Navigator.of(context)
                                          //     .pushReplacement(
                                          //   MaterialPageRoute(
                                          //     builder: (context) =>
                                          //         JCBHomeScreen(user: user),
                                          //   ),
                                          // );
                                          loginAndAuthenticateUser(context,);          
                                    },
                                    child: Text(
                                      'Login In',
                                      style: TextStyle(color: Colors.white,
                                      fontSize: 17),
                                    ),
                                    style: ButtonStyle(
                                      backgroundColor: MaterialStateProperty.all(Colors.green),
                                    ),
                                  ),
                                ),
                                SizedBox(width: 24.0),
                                Expanded(
                                  child: ElevatedButton(
                                    onPressed: () {
                                      Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (context) =>
                                              AdminSignUpScreen(),
                                        ),
                                      );
                                    },
                                    child: Text(
                                      'SignUp',
                                      style: TextStyle(color: Colors.white,
                                      fontSize: 17),
                                    ),
                                    style: ButtonStyle(
                                      backgroundColor: MaterialStateProperty.all(Colors.redAccent),
                                    ),
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                      )
       
       
           
          ],
        ).paddingSymmetric(horizontal: 16),
      ),
    );
  }
  
final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

void loginAndAuthenticateUser(BuildContext context) async {
  setState(() {
    _isProcessing = true; // Set isLoading to true before starting registration
  });

  try {
    final firebaseUser = (await _firebaseAuth.signInWithEmailAndPassword(
      email: _emailTextController.text,
      password: _passwordTextController.text,
    )).user;

    if (firebaseUser != null) {
      driversref.child(firebaseUser.uid).once().then((snap) {
        if (snap != null) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(
              builder: (context) => AdminHomeScreen(),
            ),
          );
          displayToastMessage("You are successfully logged in", context);
        } else {
          _firebaseAuth.signOut();
          displayToastMessage("No record found here", context);
        }
      });
    } else {
      displayToastMessage("Error occurred", context);
    }
  } catch (errMsg) {
    displayToastMessage(" No user found In Database", context);
  }
   finally {
    setState(() {
      _isProcessing = false; // Set isLoading to false after registration completion
    });
}

}

displayToastMessage(String message, BuildContext context)
{
  Fluttertoast.showToast(msg: message,
backgroundColor: Colors.red,

  );

}}