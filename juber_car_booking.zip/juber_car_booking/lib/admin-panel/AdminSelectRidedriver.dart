import 'dart:async';

import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

import 'AdminJCBDriverWayScreen.dart';

class AdminSelectRidedriver extends StatefulWidget {
  @override
  _AdminSelectRidedriverState createState() => _AdminSelectRidedriverState();
}

class _AdminSelectRidedriverState extends State<AdminSelectRidedriver> {
  final DatabaseReference _rideBookingRef =
      FirebaseDatabase.instance.reference().child("passengers/ridebooking");
  List<Map<String, dynamic>> _rideBookingData = [];
  Timer? _refreshTimer;
  bool _isRefreshing = false;

  @override
  void initState() {
    super.initState();
    fetchRideBookingData();
    startRefreshTimer();
  }

  void startRefreshTimer() {
    _refreshTimer = Timer.periodic(Duration(seconds: 2), (timer) {
      if (!_isRefreshing) {
        _isRefreshing = true;
        fetchRideBookingData().then((_) {
          _isRefreshing = false;
        });
      }
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> fetchRideBookingData() async {
    _rideBookingRef.once().then((event) async {
      DataSnapshot snapshot = event.snapshot;
      if (snapshot.value != null) {
        Map<dynamic, dynamic> data = snapshot.value as Map<dynamic, dynamic>;
        List<Map<String, dynamic>> rideBookingData = [];
        data.forEach((key, value) {
          Map<dynamic, dynamic> bookingData = value as Map<dynamic, dynamic>;
          bookingData['requestId'] = key.toString();
          rideBookingData.add(Map<String, dynamic>.from(bookingData));
        });
        setState(() {
          _rideBookingData.clear();
          _rideBookingData = rideBookingData;
        });
      }
    }).catchError((error) {
      print('Error fetching ride booking data: $error');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Passenger Request',
          style: TextStyle(color: Colors.black),
        ),
        backgroundColor: Colors.blueAccent,
      ),
      body: ListView.builder(
        shrinkWrap: true,
        itemCount: _rideBookingData.length,
        itemBuilder: (context, index) {
          final bookingData = _rideBookingData[index];
          return Padding(
            padding: EdgeInsets.all(16.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8.0),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.3),
                    spreadRadius: 2,
                    blurRadius: 5,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Request ${index + 1}',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8.0),
                    Text(
                      'Current Location: ${bookingData['currentLocation']}',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text('Destination Location: ${bookingData['destinationLocation']}'),
                    Text('Persons: ${bookingData['seatsOfPassenger']}'),
                    Text('Time Of The Ride: ${bookingData['timeInput']}'),
                    Text('Date of Departure: ${bookingData['dateInput']}'),
                    SizedBox(height: 16.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(
                          onPressed: () {
                            // Perform accept action here

                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => AdminJCBDriverWayScreen()),
                            );
                          },
                          child: Text('Accept'),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            // Remove request from UI and database
                            setState(() {
                              _rideBookingData.removeAt(index);
                            });
                            _rideBookingRef.child(bookingData['requestId']).remove();
                          },
                          child: Text('Cancel'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
