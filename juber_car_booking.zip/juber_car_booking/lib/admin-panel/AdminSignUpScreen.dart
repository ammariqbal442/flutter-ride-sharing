import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:nb_utils/nb_utils.dart';


import '../screens/JCBHomeScreen.dart';
import 'AdminHomeScreen.dart';

class AdminSignUpScreen extends StatefulWidget {
  static const String idScreen = "adminSignUp";

  @override
  _AdminSignUpScreenState createState() => _AdminSignUpScreenState();
}

class _AdminSignUpScreenState extends State<AdminSignUpScreen> {
  late TextEditingController _emailTextController;
  late TextEditingController _passwordTextController;
  late TextEditingController _name;
  late TextEditingController _cnic;
  late TextEditingController _vehiclename;
  late TextEditingController _vehiclenumber;
  late TextEditingController _phoneNoCont;
  bool valuefirst = false;
  bool valuesecond = false;
  bool valuethird = false;
  late DatabaseReference _databaseRef;
  bool _isProcessing = false;

  @override
  void initState() {
    super.initState();
    _emailTextController = TextEditingController();
    _passwordTextController = TextEditingController();
    _name = TextEditingController();
    _cnic = TextEditingController();
    _vehiclename = TextEditingController();
    _vehiclenumber = TextEditingController();
    _phoneNoCont = TextEditingController();
    _databaseRef = FirebaseDatabase.instance.reference().child('drivers');
  }

  @override
  void dispose() {
    _emailTextController.dispose();
    _passwordTextController.dispose();
    _name.dispose();
    _cnic.dispose();
    _vehiclename.dispose();
    _vehiclenumber.dispose();
    _phoneNoCont.dispose();
    super.dispose();
  }

  displayToastMessage(String message, BuildContext context) {
    Fluttertoast.showToast(msg: message);
  }

  void registerNewUser(BuildContext context) async {
    setState(() {
      _isProcessing = true;
    });

    try {
      if (_emailTextController.text.isEmpty ||
          _passwordTextController.text.isEmpty) {
        displayToastMessage("Please enter email and password", context);
        return;
      }

      final UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailTextController.text,
        password: _passwordTextController.text,
      );

      final User? firebaseUser = userCredential.user;

      if (firebaseUser != null) {
       String driverId = firebaseUser.uid;
       
       // final driverId = _databaseRef.push().key; // Generate a unique ID for the driver

        Map<String, dynamic> userDataMap = {
          "id": driverId,
          "name": _name.text.trim(),
          "cnic": _cnic.text.trim(),
          "vehicleNumber": _vehiclenumber.text.trim(),
          "email": _emailTextController.text.trim(),
          "password": _passwordTextController.text.trim(),
          "phone": _phoneNoCont.text.trim(),
          "car": valuefirst,
          "van": valuesecond,
          "rickshaw": valuethird,
        };

        await _databaseRef.child("user_id").child(driverId).set(userDataMap); // Store the driver's data in the database
        

        displayToastMessage(
            "Congratulations, your account has been created.", context);

        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (context) => AdminHomeScreen(),
          ),
        );
      } else {
        displayToastMessage("New user account has not been created.", context);
      }
    } catch (error) {
      displayToastMessage("Error: $error", context);
    }

    setState(() {
      _isProcessing = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
          backgroundColor: Colors.redAccent,
          title: Text('Create Account'),
          centerTitle: true,
        ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(8.0),
          child: Column(
            children: [
              SizedBox(height: 10.0),
              TextField(
                
                controller: _emailTextController,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  labelText: 'Email',
                  hintText: 'Enter your email',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 10.0),
              TextField(
                controller: _passwordTextController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password',
                  hintText: 'Enter your password',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 10.0),
              TextField(
                controller: _name,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: 'Name',
                  hintText: 'Enter your name',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 10.0),
              TextField(
                controller: _cnic,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'CNIC',
                  hintText: 'Enter your CNIC',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 10.0),
              
              SizedBox(height: 10.0),
              TextField(
                controller: _vehiclenumber,
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                  labelText: 'Vehicle Number',
                  hintText: 'Enter your vehicle number',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 10.0),
              Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
               
                  Container(
                  width: context.width() * 0.9,
                  child: 
                  IntlPhoneField(
                    
                  controller: _phoneNoCont,
    decoration: InputDecoration(
        labelText: 'Phone Number',
        labelStyle: TextStyle(fontSize: 18,
        color: Colors.black54),
        border: OutlineInputBorder(
            borderSide: BorderSide(),
        ),
    ),
    initialCountryCode: 'PK',
    onChanged: (phone) {
        print(phone.completeNumber);
    },
) ,

                ),
              ]),

 SizedBox(height: 10.0),
              CheckboxListTile(
                title: Text("Car"),
                value: valuefirst,
                onChanged: (bool? value) {
                  setState(() {
                    valuefirst = value!;
                  });
                },
              ),
              CheckboxListTile(
                title: Text("Van"),
                value: valuesecond,
                onChanged: (bool? value) {
                  setState(() {
                    valuesecond = value!;
                  });
                },
              ),
              CheckboxListTile(
                title: Text("Rickshaw"),
                value: valuethird,
                onChanged: (bool? value) {
                  setState(() {
                    valuethird = value!;
                  });
                },
              ),
              SizedBox(height: 10.0),
              _isProcessing
                  ? CircularProgressIndicator()
                  : ElevatedButton(
                      onPressed: () => registerNewUser(context),
                      child: Text('Sign Up'),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
