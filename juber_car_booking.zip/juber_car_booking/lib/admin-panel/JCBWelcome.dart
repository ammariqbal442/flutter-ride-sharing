import 'package:flutter/material.dart';
import 'package:juber_car_booking/screens/JCBWelcomeScreen.dart';
import 'package:nb_utils/nb_utils.dart';

import 'package:juber_car_booking/utils/JBCColors.dart';
import 'package:juber_car_booking/utils/JCBConstants.dart';

class JCBWelcome extends StatelessWidget {
  const JCBWelcome({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: jcbSecBackGroundColor,
      body: SizedBox(
        height: context.height(),
        child: Stack(
          children: [
            Positioned(
            //  bottom: context.height() * 0.10,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    SizedBox(height: context.statusBarHeight + 50),
                    Image.asset('images/juberCarBooking/final.png', height: 100, width: 100, fit: BoxFit.cover),
                    Text('Rider-Z', style: boldTextStyle(size: 40, fontFamily: jcbFont, color: jcbDarkColor, weight: FontWeight.w900)),
                    Image.asset(
                      'images/juberCarBooking/jcb_welcom_image.png',
                      width: context.width(),
                      height: context.height() * 0.8,
                      fit: BoxFit.cover,
                    ),

              
                  ],
                ),
              ),
            ),
              
                  Padding(
                    padding: const EdgeInsets.only(top:300,left: 15),
                    child: AppButton(
                                width: context.width() - 32,
                                child: Text('Login In As Passenger'.toUpperCase(), style: boldTextStyle(color: Colors.white)),
                                onTap: () {
                    JCBWelcomeScreen().launch(context);
                                },
                                color: Colors.green,
                                elevation: 0,
                                shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
                              ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top:380,left: 15),
                    child: AppButton(
                                width: context.width() - 32,
                                child: Text('Login In As Driver'.toUpperCase(), style: boldTextStyle(color: Colors.white)),
                                onTap: () {
                                  JCBWelcomeScreen().launch(context);
                    
                                },
                                color: Colors.black
                                ,
                                elevation: 0,
                                shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
                              ),
                  ),
          ],
        ),
      ),
    );
  }
}
