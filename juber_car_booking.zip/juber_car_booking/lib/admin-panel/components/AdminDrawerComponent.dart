import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:juber_car_booking/main.dart';
import 'package:juber_car_booking/screens/privacy_policy.dart';
import 'package:nb_utils/nb_utils.dart';

import 'package:juber_car_booking/screens/JCBMyRidesScreen.dart';
import 'package:juber_car_booking/screens/JCBPaymentMethodScreen.dart';
import 'package:juber_car_booking/screens/JCBProfileScreen.dart';
import 'package:juber_car_booking/utils/JBCColors.dart';

import '../../screens/JCBLoginScreen.dart';
import '../AdminLoginScreen.dart';

class AdminDrawerComponent extends StatefulWidget {
  const AdminDrawerComponent({Key? key}) : super(key: key);

  @override
  State<AdminDrawerComponent> createState() => _AdminDrawerComponentState();
}

class _AdminDrawerComponentState extends State<AdminDrawerComponent> {
  
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.blueGrey,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  child: Image.asset(
                    'images/juberCarBooking/jcb_face2.jpg',
                    height: 58,
                    width: 58,
                    fit: BoxFit.cover,
                  ).cornerRadiusWithClipRRect(100),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.white),
                    borderRadius: radius(100),
                  ),
                ),
                16.height,
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
              'Welcome, !', // Displaying the username here
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
                      ],
                    ),
                    IconButton(
                      icon: Icon(Icons.arrow_forward_ios, color: Colors.white, size: 16),
                      onPressed: () {
                        finish(context);
                        JCBProfileScreen().launch(context);
                      },
                    )
                  ],
                ),
              ],
            ),
          ),
          ListTile(
            minLeadingWidth: 0,
            title: Text("My rides", style: boldTextStyle()),
            leading: Icon(Icons.access_time_rounded, color: jcbGreyColor),
            onTap: () {
              finish(context);
              JCBMyRidesScreen().launch(context);
            },
          ),
          ListTile(
            minLeadingWidth: 0,
            title: Text("My payment", style: boldTextStyle()),
            leading: Icon(Icons.payment, color: jcbGreyColor),
            onTap: () {
              finish(context);
              JCBPaymentMethodScreen().launch(context);
            },
          ),
          ListTile(
            minLeadingWidth: 0,
            title: Text("Privacy & Policy", style: boldTextStyle()),
            leading: Image.asset(
              'images/juberCarBooking/jcbIcons/ic_messenger.png',
              color: jcbGreyColor,
              height: 20,
              width: 20,
              fit: BoxFit.cover,
            ),
            onTap: () {

             Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => PrivacyPolicy(),
                              ),
                            );
                          
            },
          ),
          ListTile(
            minLeadingWidth: 0,
            title: Text("Dark Mode", style: boldTextStyle()),
            leading: Image.asset(
              'images/juberCarBooking/jcbIcons/ic_theme.png',
              color: jcbGreyColor,
              height: 20,
              width: 20,
              fit: BoxFit.cover,
            ),
            trailing: Switch(
              value: appStore.isDarkModeOn,
              onChanged: (bool value) {
                appStore.toggleDarkMode(value: value);
                setState(() {});
              },
            ),
            onTap: () {},
          ),
                      WillPopScope(
  onWillPop: () async {
    final logout = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Are you sure?'),
          content: Text('Do you want to logout from this App?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: Text('Yes'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: Text('No'),
            ),
          ],
        );
      },
    );
    return logout ?? false;
  },
  child: Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(height: 16.0),
        ElevatedButton(
          onPressed: () async {
            bool? confirmLogout = await showDialog<bool>(
              context: context,
              builder: (context) {
                return AlertDialog(
                  backgroundColor: Colors.red,
                  title: Text('Confirm Logout',
                  style: TextStyle(color: Colors.white,
                  ),),
                  content: Text('Are you sure you want to logout?',
                  style: TextStyle(color: Colors.white,
                  ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context, true);
                      },
                      child: Text('Yes',
                  style: TextStyle(color: Colors.white,
                  ),),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context, false);
                      },
                      child: Text('No',
                  style: TextStyle(color: Colors.white,
                  ),),
                    ),
                  ],
                );
              },
            );
            if (confirmLogout == true) {
              await FirebaseAuth.instance.signOut();
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (context) => AdminLoginScreen(),
                ),
              );
            }
          },
          child: const Text('Logout'),
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all(Colors.redAccent),
          ),
        ),
      ],
    ),
  ),
)

        ],
      ),
    );
  }
}
