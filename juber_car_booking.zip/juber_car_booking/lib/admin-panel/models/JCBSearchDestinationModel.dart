class JCBSearchDestinationModel {
  String name;
  String address;

  JCBSearchDestinationModel({required this.name, required this.address});
}

List<JCBSearchDestinationModel> jcbDestinationsList() {
  List<JCBSearchDestinationModel> list = [];

  list.add(JCBSearchDestinationModel(name: "University of South Asia", address: 'Tufail Road Cantt Lahore'));
  list.add(JCBSearchDestinationModel(name: "Home", address: 'Ravi Road Lahore'));
  list.add(JCBSearchDestinationModel(name: "Mall Of Lahore", address: 'Tufail Road Near Fortress Lahore'));
 
  return list;
}

List<JCBSearchDestinationModel> jcbFavList() {
  List<JCBSearchDestinationModel> list = [];

  list.add(JCBSearchDestinationModel(name: "BMW of Bellevue", address: '13424 NE 20th St Bellevue,WA 98005'));
  list.add(JCBSearchDestinationModel(name: "McDonald\'s", address: '13841 NE 20th St Bellevue,WA 98005'));
  list.add(JCBSearchDestinationModel(name: "Highland Track Fiels", address: 'NE 20th St Bellevue,WA 98005'));

  return list;
}
