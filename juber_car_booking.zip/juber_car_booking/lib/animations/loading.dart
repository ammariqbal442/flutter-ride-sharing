import 'dart:async';


import 'package:flutter/material.dart';


import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:juber_car_booking/admin-panel/utils/JCBConstants.dart';
import 'package:juber_car_booking/screens/JCBSelectRidedriver.dart';
import 'package:juber_car_booking/screens/JCBSplashScreen.dart';
import 'package:nb_utils/nb_utils.dart';

import '../admin-panel/utils/JBCColors.dart';

// ignore: use_key_in_widget_constructors
class Loadingscreen extends StatefulWidget {
  static const String idscreen ="loading";

  @override
  State<Loadingscreen> createState() => _LoadingscreenState();
}

class _LoadingscreenState extends State<Loadingscreen> {
  @override
  
 void initState() {
    // TODO: implement initState
    super.initState();
    Timer(
      Duration(seconds: 5),
      ()=>  Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => JCBSplashScreen(),
              ),
            )
 
      );
    
  }
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.redAccent,
body:   
Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Use any image widget you prefer
               Image.asset('images/juberCarBooking/final.png', height: 100, width: 100, fit: BoxFit.cover),
                
                SizedBox(height: 20.0),
                    Text('Rider-Z', style: boldTextStyle(size: 40, fontFamily: jcbFont, color: jcbDarkColor, weight: FontWeight.w900)),
                
            SizedBox(height: 50.0),
            SpinKitRipple(
              color: Colors.white,  // Set the color of the spinner
              size: 70.0,         // Set the size of the spinner
            ),
          ],
        ),
      ),
    );
       
    
  }
}