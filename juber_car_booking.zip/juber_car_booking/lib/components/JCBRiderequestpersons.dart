import 'package:flutter/material.dart';
import 'package:juber_car_booking/components/JCBFoundDriverComponent.dart';
import 'package:juber_car_booking/models/JCBRiderRequestdetails.dart';
import 'package:juber_car_booking/screens/JCBBookRideScreen.dart';
import 'package:juber_car_booking/screens/JCBDriverWayScreen.dart';
import 'package:nb_utils/nb_utils.dart';

import 'package:juber_car_booking/utils/JBCColors.dart';
import 'package:juber_car_booking/utils/JCBConstants.dart';
import 'package:juber_car_booking/main.dart';

import '../screens/JCBSelectRidedriver.dart';

class JCBRideRequestComponent extends StatefulWidget {
  List<JCBRideRequestModel> requestlist;

  JCBRideRequestComponent({required this.requestlist});

  @override
  State<JCBRideRequestComponent> createState() => _JCBRideRequestComponentState();
}


class _JCBRideRequestComponentState extends State<JCBRideRequestComponent> {
 // int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: widget.requestlist.map((e) {
        int index = widget.requestlist.indexOf(e);
        return Container(
          width: context.width(),
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
          //  color: selectedIndex == index
                // ? jcbPrimaryColor.withAlpha(30)
                // : appStore.isDarkModeOn
                //     ? context.cardColor
                //     : jcbBackGroundColor,
            borderRadius: radius(25),
            border: Border.all(
              
              color: Colors.amber
              
              ),
          ),
          child: Stack(
           // mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Positioned(
                right: 290,
                top: 36,
    
     child:      Image.asset('images/juberCarBooking/points.png',height: 40,),
              
    
  ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                   
                 
             Padding(padding: EdgeInsets.only(left: 0),
             child: Text(e.title, style: boldTextStyle(color: appStore.isDarkModeOn ? Colors.white : jcbDarkColor)),
                 
             ),
                  Divider(height: 5,),
                   
                  Padding(
                    padding: const EdgeInsets.only(left: 25),
                    child: Text(e.pickuplocation, style: boldTextStyle(
                      
                      color:  Colors.green, size: 16)),
                  ),
 
Divider(height: 15,),
                 
                  Padding(
                    padding: const EdgeInsets.only(left: 25),
                    child: Text(e.destinationlocation, style: boldTextStyle(
                      color:  Colors.amber, size: 16)),
                  ),

                  Padding(
                    padding: const EdgeInsets.only(left: 25,top: 10),
                    child: Text(e.seats, style: boldTextStyle(
                      color:  Colors.grey, size: 13)),
                  ),
                   Padding(
                    padding: const EdgeInsets.only(left: 25,top: 10),
                    child: Text(e.titlevehcile, style: TextStyle(
                      color:  Colors.black,fontSize: 15)),
                  ),
                 
                  16.height,
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(e.cost, style: boldTextStyle(color: jcbPrimaryColor)),
                      20.width,
                      RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          style: secondaryTextStyle(color: jcbGreyColor),
                          children: [
                            WidgetSpan(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 2.0),
                                child: Icon(Icons.access_time_outlined, color: jcbGreyColor, size: 16),
                              ),
                            ),
                            TextSpan(text: e.time,style: TextStyle(
                              color: Colors.black,
                              fontSize: 15
                            )
                            ),
                            
                          ],
                        ),
                      ),
                      
                    ],
                  ),
                  
                ],
              ),
              
              Padding(padding: EdgeInsets.only(left: 245
              ),
              child:Image.asset(e.image, height: 70, width: 80, fit: BoxFit.fill),
 
              ),
              Padding(padding: EdgeInsets.only(left: 235,top: 80,),
              
              child: AppButton(
             // height: 10,
              
              child: Text('Accept'.toUpperCase(), style: boldTextStyle(color: Colors.white,
              size: 13)),
              onTap: () {
                JCBDriverWayScreen().launch(context);
              },
              color: Colors.lightGreen,
              shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
              elevation: 0,
            ),
            
              
              ),
                            Padding(padding: EdgeInsets.only(left: 235,top: 145,),
              
              child: AppButton(
             // height: 10,
              
              child: Text('Cancel'.toUpperCase(), style: boldTextStyle(color: Colors.white,
              size: 13)),
              onTap: () {
                JCBSelectRidedriver().launch(context);
              },
              color: jcbPrimaryColor,
              shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
              elevation: 0,
            ),
            
              
              ),

             
            ],
          ),
        ).onTap(
          () {
            //selectedIndex = index;
            setState(() {});
          },
          borderRadius: radius(jcbButtonRadius),
        ).paddingSymmetric(vertical: 8);
      }).toList(),
    );
  }
}
