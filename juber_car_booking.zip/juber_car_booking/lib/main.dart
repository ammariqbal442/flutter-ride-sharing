import 'package:flutter/material.dart';
import 'package:juber_car_booking/admin-panel/AdminHomeScreen.dart';
import 'package:juber_car_booking/animations/loading.dart';
import 'package:juber_car_booking/screens/JCBReplyScreen.dart';
import 'package:juber_car_booking/store/AppStore.dart';
import 'package:juber_car_booking/utils/AppTheme.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_core/firebase_core.dart';



void main() async {
  WidgetsFlutterBinding.ensureInitialized();
    
await Firebase.initializeApp();
  runApp(const MyApp());
}
AppStore appStore = AppStore();

// Declaration of databases
DatabaseReference usersRef = FirebaseDatabase.instance.reference().child("passengers");
final DatabaseReference driversref  = FirebaseDatabase.instance.reference().child('drivers');

// final DatabaseReference usersReff =

//       FirebaseDatabase.instance.reference().child("rideinfromation");

//DatabaseReference usersadminRef = FirebaseDatabase.instance.reference().child("usersadmin");

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
        scrollBehavior: SBehavior(),
        navigatorKey: navigatorKey,
        title: 'Rider-z',
        debugShowCheckedModeBanner: false,
        theme: AppThemeData.lightTheme,
        darkTheme: AppThemeData.darkTheme,
        themeMode: appStore.isDarkModeOn ? ThemeMode.dark : ThemeMode.light,
        home: Loadingscreen(),

        // supportedLocales: LanguageDataModel.languageLocales(),
/*        localizationsDelegates: [
          AppLocalizations(), 
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        localeResolutionCallback: (locale, supportedLocales) => locale,
        locale: Locale(appStore.selectedLanguage.validate(value: AppConstant.defaultLanguage)),*/
     
    );

  }
}
