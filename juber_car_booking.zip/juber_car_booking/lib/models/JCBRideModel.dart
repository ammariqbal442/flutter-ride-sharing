class JCBRideModel {
  String title;
  String seats;
  String cost;
  String time;
  bool? isBest;
  String image;

  JCBRideModel({required this.title, required this.seats, required this.cost, required this.time, this.isBest, required this.image});
}

List<JCBRideModel> getRideTypes() {
  List<JCBRideModel> list = [];

  list.add(JCBRideModel(
    title: 'Ride-GO',
    image: 'images/juberCarBooking/juberRides/go.png',
    cost: '\Rs,200',
    isBest: true,
    seats: '5 Seats',
    time: '1-8 min',
  ));
  list.add(JCBRideModel(
    title: 'Ride-Mini',
    image: 'images/juberCarBooking/juberRides/mini.png',
    cost: '\Rs 150',
    isBest: false,
    seats: '3 seats',
    time: '1-3 min',
  ));
  // list.add(JCBRideModel(
  //   title: 'Juberbike',
  //   image: 'images/juberCarBooking/juberRides/juber_bike.png',
  //   cost: '\$10.00',
  //   isBest: false,
  //   subTitle: 'Pay Less',
  //   time: '1-5 min',
  // ));
   list.add(JCBRideModel(
    title: 'Ride-Van',
    image: 'images/juberCarBooking/juberRides/van.png',
    cost: '\Rs 600',
    isBest: false,
    seats: '9 seats',
    time: '2-8 min',
  ));
  // list.add(JCBRideModel(
  //   title: 'Jubercar4',
  //   image: 'images/juberCarBooking/juberRides/juber_car4.png',
  //   cost: '\$45.00',
  //   isBest: false,
  //   subTitle: '4 seats',
  //   time: '1-5 min',
  // ));
  list.add(JCBRideModel(
    title: 'Auto Rakshaw',
    image: 'images/juberCarBooking/juberRides/auto.png',
    cost: '\Rs 250',
    isBest: false,
    seats: '3 seats',
    time: '1-1 min',
  ));

  return list;
}

List<JCBRideModel> getMyRides() {
  List<JCBRideModel> list = [];

  list.add(JCBRideModel(
    title: 'JuberGo',
    image: 'images/juberCarBooking/jcb_map.png',
    cost: '\Rs 25.50',
    seats: 'Seattle - 280 Hemlock Ln',
    time: 'Today, 10 : 30 AM',
  ));
  list.add(JCBRideModel(
    title: 'Jubercar',
    image: 'images/juberCarBooking/jcb_map.png',
    cost: '\Rs 35.00',
    seats: 'Home - Woodland Park',
    time: 'May 29,2022  08:15 AM',
  ));

  return list;
}
