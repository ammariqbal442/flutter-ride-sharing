class JCBRideRequestModel {
  String title;
  String titlevehcile;
  String pickuplocation;
  String cost;
  String time;
  String seats;
  String destinationlocation;
  String image;

  JCBRideRequestModel({required this.title, required this.titlevehcile,required this.seats, required this.pickuplocation, required this.cost, required this.time, required this.destinationlocation, required this.image});

  
}

List<JCBRideRequestModel> getRiderequestTypes() {
  List<JCBRideRequestModel> list = [];

  list.add(JCBRideRequestModel(
    title: 'Muhhamad Azam',
       titlevehcile: 'Toyota Corola',
    image: 'images/juberCarBooking/pc1.png',
    cost: '\Rs,200',
    destinationlocation: "Azadi Chowk",
    pickuplocation: 'Aftab Chwo St 8',
    seats: 'Seats 3',
    time: '1-8 min',
  ));
  list.add(JCBRideRequestModel(
    title: 'Ahmer Manzoor',
     titlevehcile: 'Mehran Mini',
    image: 'images/juberCarBooking/pc2.png',
    cost: '\Rs 150',
    destinationlocation: "Fortress Stadium Cantt",
    pickuplocation: 'Amin park st 2 Ravi Road',
     seats: 'Seats 4',
    time: '1-3 min',
  ));
  // list.add(JCBRideModel(
  //   title: 'Juberbike',
  //   image: 'images/juberCarBooking/juberRides/juber_bike.png',
  //   cost: '\$10.00',
  //   isBest: false,
  //   subTitle: 'Pay Less',
  //   time: '1-5 min',
  // ));
   list.add(JCBRideRequestModel(
    title: 'Sameer Ahmed',
     titlevehcile: 'Changan Karvaan',
    image: 'images/juberCarBooking/jcb_face2.jpg',
    cost: '\Rs 600',
    destinationlocation: "Mall Of Lahore cantt",
    pickuplocation: 'Lahore hotel garhi shahu',
     seats: 'Seats 6',
    time: '2-8 min',
  ));

  return list;
}
