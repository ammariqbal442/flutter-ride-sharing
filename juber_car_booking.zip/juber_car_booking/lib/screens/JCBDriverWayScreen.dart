import 'package:flutter/material.dart';
import 'package:juber_car_booking/components/JCBAlertDialogComponent.dart';
import 'package:juber_car_booking/components/JCBCancelBookingComponent.dart';
import 'package:juber_car_booking/components/JCBFoundDriverComponent.dart';
import 'package:juber_car_booking/screens/JCBRatingScreen.dart';
import 'package:juber_car_booking/utils/JBCColors.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:juber_car_booking/utils/JCBCommon.dart';
import 'package:juber_car_booking/utils/JCBConstants.dart';
import 'package:juber_car_booking/main.dart';

class JCBDriverWayScreen extends StatefulWidget {
  @override
  State<JCBDriverWayScreen> createState() => _JCBDriverWayScreenState();
}

class _JCBDriverWayScreenState extends State<JCBDriverWayScreen> {
  bool showLoader = false;
  bool showBottomSheet = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: jcbDarkColor,
      appBar: AppBar(
        leading: IconButton(
          icon: Image.asset(
            'images/juberCarBooking/jcbIcons/ic_close.png',
            height: 20,
            width: 20,
            fit: BoxFit.cover,
            color: Colors.white,
          ),
          onPressed: () {
            finish(context);
          },
          color: appStore.isDarkModeOn ? Colors.white : jcbDarkColor,
        ),
        title: Text('Driver on the way', style: boldTextStyle(color: Colors.white)),
        backgroundColor: jcbDarkColor,
        centerTitle: true,
        elevation: 0,
      ),
      body: 
      Container(
        width: context.width() - 32,
        margin: EdgeInsets.all(16),
        decoration: BoxDecoration(color: context.scaffoldBackgroundColor, borderRadius: radius(jcbBottomSheetRadius)),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              16.height,
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 110,
                    child: Stack(
                      alignment: Alignment.topCenter,
                      children: [
                        Image.asset(
                          'images/juberCarBooking/pc1.png',
                          height: 100,
                          width: 100,
                          fit: BoxFit.cover,
                        ).cornerRadiusWithClipRRect(100),
                        Positioned(
                          bottom: 0,
                          child: Container(
                            width: 100,
                            padding: EdgeInsets.symmetric(vertical: 4),
                            decoration: BoxDecoration(color: jcbPrimaryColor, borderRadius: radius(jcbBottomSheetRadius)),
                            child: Text('Ride-Go'.toUpperCase(), style: boldTextStyle(color: Colors.white, size: 14), textAlign: TextAlign.center),
                          ),
                        )
                      ],
                    ),
                  ),
                  16.width,
                   showLoader
              ? Container(
            width: context.width(),
            decoration: BoxDecoration(
                color: context.scaffoldBackgroundColor,
                borderRadius: radiusOnly(topLeft: jcbBottomSheetRadius, topRight: jcbBottomSheetRadius)),
            padding: EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset(
                  'images/juberCarBooking/jcbGifs/jcb_loader.gif',
                  height: 80,
                  width: 80,
                  fit: BoxFit.cover,
                ),
                Text(
                  'We are processing your booking...'.toUpperCase(),
                  style: boldTextStyle(color: appStore.isDarkModeOn ? Colors.white : jcbDarkColor),
                ),
                8.height,
                Text('Your ride will start soon', style: secondaryTextStyle(color: jcbGreyColor)),
                20.height,
              ],
            ),
          ):
         
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('Muhhamad Azam', style: boldTextStyle(size: 18, color: appStore.isDarkModeOn ? Colors.white : jcbDarkColor)),
                      Container(
                        height: 20,
                        child: ListView.builder(
                          shrinkWrap: true,
                          itemBuilder: (context, index) => Icon(index == 4 ? Icons.star_border : Icons.star, color: jcbSecondaryColor, size: 16),
                          itemCount: 5,
                          scrollDirection: Axis.horizontal,
                        ),
                      ).onTap(() {
                        JCBRatingScreen().launch(context);
                      }, splashColor: Colors.transparent, highlightColor: Colors.transparent),
                      10.height,
                      RichText(
                        text: TextSpan(
                          text: 'ST3571 ',
                          style: boldTextStyle(),
                          children: <TextSpan>[
                            TextSpan(text: '- Toyoto Corola', style: secondaryTextStyle(color: Colors.black)),
                          ],
                        ),
                      )
                    ],
                  )
                ],
              ).paddingSymmetric(horizontal: 16),
              20.height,
              jcbTicketLineComponent(context),
              16.height,
              Text('FARE', style: boldTextStyle(color: Colors.black)),
              8.height,
              Text('\Rs 500', style: boldTextStyle(color: jcbPrimaryColor, size: 40)),
              8.height,
              Text('inc. tax', style: secondaryTextStyle(color: Colors.black)),
              16.height,
              Divider(),
              16.height,
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Column(
                    children: [
                      Icon(Icons.circle, color: context.iconColor, size: 14),
                      jcbDottedLineComponent(height: 24),
                      Icon(Icons.square, color: jcbPrimaryColor, size: 16),
                     ],
                  ),
                  8.width,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                         // Text('Pick-up'.toUpperCase(), style: secondaryTextStyle(color: jcbSecBorderColor, size: 10)),
                          Text('Aftab Chowk St 8', style: boldTextStyle(size: 14)),
                        ],
                      ),
                      19.height,
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                         // Text('destination #1'.toUpperCase(), style: secondaryTextStyle(color: Colors.black, size: 10)),
                          Text('Azadi Chowk', style: boldTextStyle(size: 14)),
                        ],
                      ),
                     
                    ],
                  ).expand(),
                ],
              ).paddingSymmetric(horizontal: 16),
              50.height,
              AppButton(
                width: context.width() - 32,
                
                child: Text('Cancel booking'.toUpperCase(), style: boldTextStyle(color: Colors.white)),
                onTap: () {
                  showModalBottomSheet(
                      context: context,
                      isScrollControlled: true,
                      enableDrag: true,
                      isDismissible: false,
                      shape: RoundedRectangleBorder(borderRadius: radiusOnly(topLeft: 30, topRight: 30)),
                      builder: (context) {
                        return Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            JCBCancelBookingComponent(),
                            16.height,
                            AppButton(
                              width: context.width() - 32,
                              child: Text('Keep the booking'.toUpperCase(), style: boldTextStyle(color: Colors.white)),
                              onTap: () {
                                finish(context);
                              },
                              color: jcbPrimaryColor,
                              shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
                              elevation: 0,
                            ),
                            8.height,
                            AppButton(
                              width: context.width() - 32,
                              splashColor: Colors.amber,
                              child: Text('cancel ride'.toUpperCase(), style: boldTextStyle(color: jcbPrimaryColor)),
                              onTap: () {
                                finish(context);
                                finish(context);
                              },
                              color: context.scaffoldBackgroundColor,
                              shapeBorder: RoundedRectangleBorder(
                                borderRadius: radius(jcbButtonRadius),
                                side: BorderSide(color: jcbPrimaryColor),
                              ),
                              elevation: 0,
                            ),
                            16.height,
                          ],
                        );
                      });
                },
                color: Colors.redAccent,
                shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
                elevation: 0,
              ).paddingAll(16),
              
            ],
          ),
        ),
      ),

       bottomNavigationBar: showLoader
          ? Dismissible(
        key: Key(''),
        child: Container(
          decoration: BoxDecoration(color: jcbGreyColor.withAlpha(80), borderRadius: radius(50)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(Icons.cancel, size: 40, color: Colors.white),
              Text('Slide to cancel'.toUpperCase(), style: boldTextStyle(color: Colors.white, size: 18)),
              16.width,
            ],
          ),
        ),
        onDismissed: (_) {
          showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              enableDrag: true,
              isDismissible: false,
              shape: RoundedRectangleBorder(borderRadius: radiusOnly(topLeft: 30, topRight: 30)),
              builder: (context) {
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    JCBCancelBookingComponent(),
                    16.height,
                    AppButton(
                      width: context.width() - 32,
                      child: Text('Keep the booking'.toUpperCase(), style: boldTextStyle(color: Colors.white)),
                      onTap: () {
                        finish(context);
                      },
                      color: jcbPrimaryColor,
                      shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
                      elevation: 0,
                    ),
                    8.height,
                    AppButton(
                      width: context.width() - 32,
                      child: Text('cancel ride'.toUpperCase(), style: boldTextStyle(color: jcbPrimaryColor)),
                      onTap: () {
                        showLoader = false;
                        showBottomSheet = false;
                        setState(() {});
                        finish(context);
                      },
                      color: context.scaffoldBackgroundColor,
                      shapeBorder: RoundedRectangleBorder(
                        borderRadius: radius(jcbButtonRadius),
                        side: BorderSide(color: jcbPrimaryColor),
                      ),
                      elevation: 0,
                    ),
                    16.height,
                  ],
                );
              });
        },
      ).paddingSymmetric(horizontal: 16, vertical: 16)
          : AppButton(
        child: Text('Driver Contact'.toUpperCase(), style: boldTextStyle(color: Colors.white)),
        onTap: () async {
          
            await Future.delayed(Duration(seconds: 2)).then((value) async {
              showLoader = false;
              setState(() {});

              if (showBottomSheet) {
                showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    enableDrag: true,
                    isDismissible: false,
                    shape: RoundedRectangleBorder(borderRadius: radiusOnly(topLeft: 30, topRight: 30)),
                    builder: (context) {
                      return JCBFoundDriverComponent();
                    });

                await Future.delayed(Duration(seconds: 1)).then((value) {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        content: JCBAlertDialogComponent(),
                      );
                    },
                  );
                });
              } else {
                showBottomSheet = true;
                setState(() {});
              }
            });
          
        },
        color: Colors.green,
        elevation: 0,
        shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
      ).paddingOnly(left: 16, right: 16, bottom: 16),
    

    );
  }
}
