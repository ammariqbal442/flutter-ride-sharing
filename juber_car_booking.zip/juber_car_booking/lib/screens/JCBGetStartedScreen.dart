import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:juber_car_booking/screens/JCBHomeScreen.dart';
import 'package:juber_car_booking/utils/JBCColors.dart';
import 'package:juber_car_booking/utils/JCBConstants.dart';

class JCBGetStartedScreen extends StatefulWidget {
      final User user;
  
   JCBGetStartedScreen({required this.user});

  @override
  State<JCBGetStartedScreen> createState() => _JCBGetStartedScreenState();
}

class _JCBGetStartedScreenState extends State<JCBGetStartedScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: jcbSecBackGroundColor,
      body: SizedBox(
        height: context.height(),
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            Column(
              children: [
                SizedBox(height: context.statusBarHeight + 40),
                Image.asset(
                  'images/juberCarBooking/tick.png',
                  color: Colors.green,
                  height: 110,
                  width: 110,
                  fit: BoxFit.cover,
                ),
                10.height,
                Text(
                  'You are ready to go!',
                  style: boldTextStyle(size: 25, fontFamily: jcbFont, color: Colors.white, weight: FontWeight.w900),
                  textAlign: TextAlign.center,
                ),
                10.height,
                Text(
                  'Thanks for taking your time to create \naccount with us. Now this is the fun part, \nlet\'s explore the app.',
                  style: primaryTextStyle(color: Colors.black, weight: FontWeight.w600),
                  textAlign: TextAlign.center,
                ),
                //40.height,
              ],
            ),
            Positioned(
              bottom: 0,
              
              child: Image.asset(
                'images/juberCarBooking/jcb_walkthrough3.png',
                width: context.width(),
                fit: BoxFit.cover,
              ),
            ),
            AppButton(
              width: context.width() - 60,
              child: Text('Get started'.toUpperCase(), style: boldTextStyle(color: jcbPrimaryColor)),
              onTap: () {
               // JCBHomeScreen(user: User,);
              },
              color: jcbDarkColor,
              shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
              elevation: 0,
            ).center(),
          ],
        ),
      ),
    );
  }
}
