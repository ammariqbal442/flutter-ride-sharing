import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:juber_car_booking/screens/JCBFavouriteScreen.dart';
import 'package:juber_car_booking/screens/JCBLoginScreen.dart';
import 'package:juber_car_booking/screens/JCBMyRidesScreen.dart';
import 'package:juber_car_booking/screens/JCBPaymentMethodScreen.dart';
import 'package:juber_car_booking/screens/JCBProfileScreen.dart';
import 'package:juber_car_booking/screens/privacy_policy.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:juber_car_booking/components/JCBDrawerComponent.dart';
import 'package:juber_car_booking/screens/JCBSearchDestinationScreen.dart';
import 'package:juber_car_booking/utils/JBCColors.dart';
import 'package:juber_car_booking/utils/JCBConstants.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:juber_car_booking/main.dart';

final GlobalKey<ScaffoldState> jcbHomeKey = GlobalKey();

// ignore: must_be_immutable
class JCBHomeScreen extends StatefulWidget {
  //  final User user;
  
  //  JCBHomeScreen({required this.user});
  static const CameraPosition initialCameraPosition = CameraPosition(target: LatLng(37.42796133580664, -122.085749655962), zoom: 14);

  @override
  State<JCBHomeScreen> createState() => _JCBHomeScreenState();
}

class _JCBHomeScreenState extends State<JCBHomeScreen> {
   
   late GoogleMapController googleMapController;

GoogleMapController? mapController;

 Set<Marker> markers = {};

  // declaration of dropdownmenu items
    String? selectedValue = null;

    String location = "Search Location";

    String googleApikey = "AIzaSyAmAiqgDzdYHdWpY_JwrXtICmIhnNT6AsM";
//  @override
//   void initState() {
//     _currentUser = widget.user;
//     super.initState();
//   }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: jcbHomeKey,
      
      drawer: new Drawer(
       child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: jcbPrimaryColor,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  child: Image.asset(
                    'images/juberCarBooking/jcb_face2.jpg',
                    height: 58,
                    width: 58,
                    fit: BoxFit.cover,
                  ).cornerRadiusWithClipRRect(100),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.white),
                    borderRadius: radius(100),
                  ),
                ),
                16.height,
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
              SizedBox(height: 16.0),
  
                      ],
                    ),
                    IconButton(
                      icon: Icon(Icons.arrow_forward_ios, color: Colors.white, size: 16),
                      onPressed: () {
                        finish(context);
                        JCBProfileScreen().launch(context);
                      },
                    )
                  ],
                ),
              ],
            ),
          ),
          ListTile(
            minLeadingWidth: 0,
            title: Text("My rides", style: boldTextStyle()),
            leading: Icon(Icons.access_time_rounded, color: jcbGreyColor),
            onTap: () {
              finish(context);
              JCBMyRidesScreen().launch(context);
            },
          ),
          ListTile(
            minLeadingWidth: 0,
            title: Text("My favourites", style: boldTextStyle()),
            leading: Icon(Icons.star_border, color: jcbGreyColor),
            onTap: () {
              finish(context);
              JCBFavouriteScreen().launch(context);
            },
          ),
          ListTile(
            minLeadingWidth: 0,
            title: Text("My payment", style: boldTextStyle()),
            leading: Icon(Icons.payment, color: jcbGreyColor),
            onTap: () {
              finish(context);
              JCBPaymentMethodScreen().launch(context);
            },
          ),
          ListTile(
            minLeadingWidth: 0,
            title: Text("Notification", style: boldTextStyle()),
            leading: Icon(Icons.notifications_none_outlined, color: jcbGreyColor),
            onTap: () {},
          ),
          ListTile(
            minLeadingWidth: 0,
            title: Text("Privacy & Policy", style: boldTextStyle()),
            leading: Image.asset(
              'images/juberCarBooking/jcbIcons/ic_messenger.png',
              color: jcbGreyColor,
              height: 20,
              width: 20,
              fit: BoxFit.cover,
            ),
            onTap: () {

             Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => PrivacyPolicy(),
                              ),
                            );
                          
            },
          ),
          ListTile(
            minLeadingWidth: 0,
            title: Text("Dark Mode", style: boldTextStyle()),
            leading: Image.asset(
              'images/juberCarBooking/jcbIcons/ic_theme.png',
              color: jcbGreyColor,
              height: 20,
              width: 20,
              fit: BoxFit.cover,
            ),
            trailing: Switch(
              value: appStore.isDarkModeOn,
              onChanged: (bool value) {
                appStore.toggleDarkMode(value: value);
                setState(() {});
              },
            ),
            onTap: () {},
          ),

           WillPopScope(
  onWillPop: () async {
    final logout = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Are you sure?'),
          content: Text('Do you want to logout from this App?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: Text('Yes'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: Text('No'),
            ),
          ],
        );
      },
    );
    return logout ?? false;
  },
  child: Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(height: 16.0),
        ElevatedButton(
          onPressed: () async {
            bool? confirmLogout = await showDialog<bool>(
              context: context,
              builder: (context) {
                return AlertDialog(
                  backgroundColor: Colors.red,
                  title: Text('Confirm Logout',
                  style: TextStyle(color: Colors.white,
                  ),),
                  content: Text('Are you sure you want to logout?',
                  style: TextStyle(color: Colors.white,
                  ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context, true);
                      },
                      child: Text('Yes',
                  style: TextStyle(color: Colors.white,
                  ),),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context, false);
                      },
                      child: Text('No',
                  style: TextStyle(color: Colors.white,
                  ),),
                    ),
                  ],
                );
              },
            );
            if (confirmLogout == true) {
              await FirebaseAuth.instance.signOut();
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (context) => JCBLoginScreen(),
                ),
              );
            }
          },
          child: const Text('Logout'),
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all(Colors.redAccent),
          ),
        ),
      ],
    ),
  ),
)

                   ],
      ),   
         ),
    
  
  
      body: Stack(
        alignment: Alignment.bottomCenter,
        children: [
 GoogleMap(
        initialCameraPosition: JCBHomeScreen.initialCameraPosition,
        markers: markers,
      
        zoomControlsEnabled: true,
        
        mapType: MapType.normal,
        onMapCreated: (GoogleMapController controller) {
          googleMapController = controller;
        },
      ),

           Container(
            decoration: BoxDecoration(
                color: Colors.yellow, borderRadius: radiusOnly(topLeft: jcbBottomSheetRadius, topRight: jcbBottomSheetRadius)),
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              
              children: [
                  Padding(
        padding: const EdgeInsets.only(bottom:10, ),
        child: SizedBox(
        width: 100, // Adjust the width as needed
        child: FloatingActionButton.extended(
          onPressed: () async {
            Position position = await _determinePosition();
      
            googleMapController.animateCamera(CameraUpdate.newCameraPosition(
              CameraPosition(
                target: LatLng(position.latitude, position.longitude),
                zoom: 14,
              ),
            ));
      
            markers.clear();
      
            markers.add(
              Marker(
                markerId: const MarkerId('currentLocation'),
                position: LatLng(position.latitude, position.longitude),
              ),
            );
      
            setState(() {});
          },
          backgroundColor: Colors.white,
          label: Text("Get",style: 
          TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black
          )),
          
          icon: const Icon(Icons.location_on,
          color: Colors.amber,),
        ),
          ),
      ),
  
              
                Text(
                  'Where are you going?',
                  style: boldTextStyle(
                      size: 26, fontFamily: jcbFont, color: appStore.isDarkModeOn ? Colors.white : jcbDarkColor, weight: FontWeight.w900),
                ),
                16.height,
                Text('Book on demand or pre-schedule rides', style: secondaryTextStyle(color: Colors.black,size: 15)),
                16.height,
                Container(
                  padding: EdgeInsets.only(left: 16),
                  decoration: BoxDecoration(
                    borderRadius: radius(jcbButtonRadius),
                    border: Border.all(color: Colors.black),
                  ),
                  child: AppTextField(
                    autoFocus: false,
                    textFieldType: TextFieldType.NAME,
                    textStyle: boldTextStyle(),
                    onChanged: (val) {
                      hideKeyboard(context);
                      JCBSearchDestinationScreen().launch(context);
                    },
                    onTap: () {
                      hideKeyboard(context);
                      JCBSearchDestinationScreen().launch(context);
                    },
                    decoration: InputDecoration(
                      suffixIcon: Image.asset(
                        'images/juberCarBooking/jcbIcons/ic_search.png',
                        height: 14,
                        width: 14,
                        fit: BoxFit.cover,
                        color: jcbPrimaryColor,
                      ).paddingAll(12),
                      border: InputBorder.none,
                      hintText: 'Enter Destination',
                      hintStyle: boldTextStyle(color: Colors.black),
                    ),
                  ),
                ),
                16.height,
              ],
            ),
          ),
          Positioned(
            right: 16,
            bottom: 200,
            child: Container(
              decoration: BoxDecoration(
                color: context.scaffoldBackgroundColor,
                borderRadius: radius(8),
              ),
              child: IconButton(
                icon: Image.asset('images/juberCarBooking/jcbIcons/ic_navigation.png', height: 20, width: 20, fit: BoxFit.cover),
                onPressed: () {
                  JCBSearchDestinationScreen().launch(context);
                },
              ),
            ),
          ),
           Positioned(
            left: 16,
            top: context.statusBarHeight + 16,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: radius(100),
                border: Border.all(color: context.scaffoldBackgroundColor, width: 2),
              ),
              child: Image.asset(
                'images/juberCarBooking/jcb_face2.jpg',
                height: 40,
                width: 40,
                fit: BoxFit.cover,
              ).cornerRadiusWithClipRRect(100).onTap(() {
                jcbHomeKey.currentState!.openDrawer();
              }, borderRadius: radius(100)),
            ),
          )
        ],
      ),
    );
  }
 
  Future<dynamic> Logout() async {

    await FirebaseAuth.instance.signOut();

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (context) => JCBLoginScreen(),
      ),
    );
  }
  
  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      return Future.error('Location services are disabled');
    }

    permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();

      if (permission == LocationPermission.denied) {
        return Future.error("Location permission denied");
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error('Location permissions are permanently denied');
    }

    Position position = await Geolocator.getCurrentPosition();

    return position;
  }


  
  
}

  