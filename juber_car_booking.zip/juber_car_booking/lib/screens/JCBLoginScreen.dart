// ignore_for_file: must_be_immutable

import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:juber_car_booking/firebase_auth/validator.dart';
import 'package:juber_car_booking/screens/JCBHomeScreen.dart';
import 'package:juber_car_booking/screens/JCBSignUpScreen.dart';

class JCBLoginScreen extends StatefulWidget {
  @override
  State<JCBLoginScreen> createState() => _JCBLoginScreenState();
}

class _JCBLoginScreenState extends State<JCBLoginScreen> {


  TextEditingController emailCont = TextEditingController();

  TextEditingController passwordCont = TextEditingController();

  FocusNode email = FocusNode();

  FocusNode password = FocusNode();

    GlobalKey<FormState> _abcKey = GlobalKey<FormState>();

  final _emailTextController = TextEditingController();
  final _passwordTextController = TextEditingController();

  final _focusEmail = FocusNode();
  final _focusPassword = FocusNode();

 bool _isProcessing = false;

  Future<FirebaseApp> _initializeFirebase() async {
    FirebaseApp firebaseApp = await Firebase.initializeApp();

    User? user = FirebaseAuth.instance.currentUser;

    if (user != null) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => JCBHomeScreen(
          
          ),
        ),
      );
    }

    return firebaseApp;
  }


  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        _focusEmail.unfocus();
        _focusPassword.unfocus();
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.redAccent,
          title: Text('Login In'),
          centerTitle: true,
        ),
        body:
        
         SingleChildScrollView (
           child: FutureBuilder(
            future: _initializeFirebase(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {
                return Padding(
                  padding: const EdgeInsets.only(left: 24.0, right: 24.0,top: 48),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 120,
                        width: 120,
                        child: Image.asset("images/juberCarBooking/final.png"),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(bottom: 30.0,top: 12),
                        child: Text(
                          'Welcome to Login In',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 25
                          )
                        ),
                      ),
                      Form(
                        key: _abcKey,
                        child: Column(
                          children: <Widget>[
                            TextFormField(
                              controller: _emailTextController,
                              focusNode: _focusEmail,
                              validator: (value) => Validator.validateEmail(
                                email: value,
                              ),
                              decoration: InputDecoration(
                                hintText: "Email",
                                errorBorder: UnderlineInputBorder(
                                  borderRadius: BorderRadius.circular(6.0),
                                  borderSide: BorderSide(
                                    color: Colors.red,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: 8.0),
                            TextFormField(
                              controller: _passwordTextController,
                              focusNode: _focusPassword,
                              obscureText: true,
                              validator: (value) => Validator.validatePassword(
                                password: value,
                              ),
                              decoration: InputDecoration(
                                hintText: "Password",
                                errorBorder: UnderlineInputBorder(
                                  borderRadius: BorderRadius.circular(6.0),
                                  borderSide: BorderSide(
                                    color: Colors.red,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: 24.0),
                            _isProcessing
                            ? CircularProgressIndicator()
                            : Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: ElevatedButton(
                                    onPressed: ()  {
                                      _focusEmail.unfocus();
                                      _focusPassword.unfocus();
         
                                      
                                        
                                          // Navigator.of(context)
                                          //     .pushReplacement(
                                          //   MaterialPageRoute(
                                          //     builder: (context) =>
                                          //         JCBHomeScreen(user: user),
                                          //   ),
                                          // );
                                          loginAndAuthenticateUser(context);
                       
                                     
                                      
                                    },
                                    child: Text(
                                      'Login In',
                                      style: TextStyle(color: Colors.white,
                                      fontSize: 17),
                                    ),
                                    style: ButtonStyle(
                                      backgroundColor: MaterialStateProperty.all(Colors.green),
                                    ),
                                  ),
                                ),
                                SizedBox(width: 24.0),
                                Expanded(
                                  child: ElevatedButton(
                                    onPressed: () {
                                      Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (context) =>
                                              JCBSignUpScreen(),
                                        ),
                                      );
                                    },
                                    child: Text(
                                      'SignUp',
                                      style: TextStyle(color: Colors.white,
                                      fontSize: 17),
                                    ),
                                    style: ButtonStyle(
                                      backgroundColor: MaterialStateProperty.all(Colors.redAccent),
                                    ),
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                      )
       
       
                    ],
                  ),
                );
              }
         
              return const Center(
                child: CircularProgressIndicator(),
              );
            },
                 ),
         ),
      ),
    );
  }
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
final DatabaseReference usersRef = FirebaseDatabase.instance.reference().child("passengers");

void loginAndAuthenticateUser(BuildContext context) async {
  setState(() {
    _isProcessing = true;
  });

  try {
    final firebaseUser = (await _firebaseAuth.signInWithEmailAndPassword(
      email: _emailTextController.text,
      password: _passwordTextController.text,
    )).user;

    if (firebaseUser != null) {
      usersRef.child(firebaseUser.uid).once().then((DataSnapshot snap) {
        if (snap.value != null) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(
              builder: (context) => JCBHomeScreen(),
            ),
          );
          displayToastMessage("You are successfully logged in", context);
        } else {
          _firebaseAuth.signOut();
          displayToastMessage("No record found here", context);
        }
      } as FutureOr Function(DatabaseEvent value));
    } else {
      displayToastMessage("Error occurred", context);
    }
  } catch (errMsg) {
    displayToastMessage("You are successfully logged in", context);
  } finally {
    setState(() {
      _isProcessing = false;
    });
  }
}

displayToastMessage(String message, BuildContext context)
{
  Fluttertoast.showToast(msg: message,
backgroundColor: Colors.red,
  );
}
}


