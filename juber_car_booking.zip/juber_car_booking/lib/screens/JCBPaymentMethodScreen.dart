import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:juber_car_booking/screens/JCBSelectRidedriver.dart';
import 'package:juber_car_booking/screens/JCBSuggestedRidesScreen.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:juber_car_booking/components/JCBPaymentCard.dart';
import 'package:juber_car_booking/models/JCBCommonModel.dart';

import 'package:juber_car_booking/utils/JBCColors.dart';
import 'package:juber_car_booking/utils/JCBConstants.dart';
import 'package:juber_car_booking/main.dart';

class JCBPaymentMethodScreen extends StatefulWidget {
  const JCBPaymentMethodScreen({Key? key}) : super(key: key);

  @override
  State<JCBPaymentMethodScreen> createState() => _JCBPaymentMethodScreenState();
}

class _JCBPaymentMethodScreenState extends State<JCBPaymentMethodScreen> {
  List<JCBCommonModel> cardList = jcbPaymentSelection();

  bool defaultMethod = true;

 String? selectedIndex;

 String payment='Cash Method';

void _savepaymentToDatabase() 
{
  if (selectedIndex != null) {
    DatabaseReference paymentRef = usersRef.child("payment_method");
    paymentRef.push().set({"selectedValue": selectedIndex});
  }
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Image.asset(
            'images/juberCarBooking/jcbIcons/ic_close.png',
            height: 20,
            width: 20,
            fit: BoxFit.cover,
            color: Colors.red,
          ),
          onPressed: () {
            finish(context);
          },
        ),
      
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Payment methods', style: boldTextStyle(size: 30, fontFamily: jcbFont, color: appStore.isDarkModeOn ? Colors.white : jcbDarkColor, weight: FontWeight.w900)),
            20.height,
            Text('CURRENT METHOD', style: secondaryTextStyle(color: Colors.amber,size: 15)),
            16.height,
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: radius(jcbButtonRadius),
                border: Border.all(color: jcbSecBorderColor),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        child: Icon(Icons.monetization_on, color: Colors.white),
                        padding: EdgeInsets.symmetric(vertical: 4, horizontal: 14),
                        decoration: BoxDecoration(color: jcbSecondaryColor, borderRadius: radius(jcbButtonRadius)),
                      ),
                      20.width,
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Cash payment', style: boldTextStyle(color: appStore.isDarkModeOn ? Colors.white : jcbDarkColor)),
                          Text('Default method', style: secondaryTextStyle(color: jcbGreyColor)),
                        ],
                      ),
                    ],
                  ),
                  Checkbox(
                    value: defaultMethod,
                    onChanged: (val) {
                      defaultMethod = val.validate();
                      setState(() {});
                    },
                    activeColor: jcbPrimaryColor,
                  ),
                ],
              ),
            ),
           
            50.height,
          
            // AppButton(
            //   width: context.width() - 32,
            //   child: Text('add payment method'.toUpperCase(), style: boldTextStyle(color: Colors.white)),
            //   onTap: () {
            //     JCBAddPaymentCardScreen().launch(context).then((value) {
            //       cardList.add(value);
            //       setState(() {});
            //     });
            //   },
            //   color: jcbPrimaryColor,
            //   shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
            //   elevation: 0,
            // ),

               AppButton(
              width: context.width() - 32,
              child: Text('Pay'.toUpperCase(), style: boldTextStyle(color: Colors.white)),
              onTap: () {
              JCBSelectRidedriver().launch(context);

               setState(() {
              selectedIndex = payment;
            });
            
             _savepaymentToDatabase(); 
              },
              color: jcbPrimaryColor,
              elevation: 0,
              shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
            ),
          
          ],
        ),
      ),
    );
  }
}
