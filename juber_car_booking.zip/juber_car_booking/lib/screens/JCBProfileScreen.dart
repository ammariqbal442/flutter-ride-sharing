import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:juber_car_booking/screens/JCBSuggestedRidesScreen.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:juber_car_booking/components/JCBFormTextField.dart';
import 'package:juber_car_booking/utils/JBCColors.dart';
import 'package:juber_car_booking/utils/JCBConstants.dart';
import 'package:juber_car_booking/main.dart';
import 'package:juber_car_booking/screens/JCBHomeScreen.dart';

class JCBProfileScreen extends StatefulWidget {
  
  @override
  State<JCBProfileScreen> createState() => _JCBProfileScreenState();
}

class _JCBProfileScreenState extends State<JCBProfileScreen> {
  bool isPref = true;
  
final FirebaseAuth auth = FirebaseAuth.instance;
_googleSignUp() async {
    try {
      final GoogleSignIn _googleSignIn = GoogleSignIn(
        scopes: ['email'],
      );
      final FirebaseAuth _auth = FirebaseAuth.instance;

      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      final GoogleSignInAuthentication? googleAuth =
      await googleUser?.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth?.accessToken,
        idToken: googleAuth?.idToken,
      );

      final User? user = (await _auth.signInWithCredential(credential)).user;
      //print("signed in " + user.displayName);

      return user;
    } catch (e) {
    }
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Image.asset(
            'images/juberCarBooking/jcbIcons/ic_close.png',
            height: 20,
            width: 20,
            fit: BoxFit.cover,
            color: context.iconColor,
          ),
          onPressed: () {
            finish(context);
          },
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Hi Amaar',
                  style: boldTextStyle(
                      size: 30, fontFamily: jcbFont, color: appStore.isDarkModeOn ? Colors.white : jcbDarkColor, weight: FontWeight.w900),
                ),
                Image.asset(
                  'images/juberCarBooking/jcb_face2.jpg',
                  height: 58,
                  width: 58,
                  fit: BoxFit.cover,
                ).cornerRadiusWithClipRRect(100)
              ],
            ),
            20.height,
            JCBFormTextField(
              label: 'Name'.toUpperCase(),
              textFieldType: TextFieldType.NAME, validator: (value) {  },
            ),
            16.height,
            JCBFormTextField(
              label: 'Email'.toUpperCase(),
              textFieldType: TextFieldType.EMAIL, validator: (value) {  },
            ),
            16.height,
            JCBFormTextField(
              label: 'Phone Number'.toUpperCase(),
              textFieldType: TextFieldType.PHONE,
              keyboardType: TextInputType.number, validator: (value) {  },
            ),
            16.height,
            JCBFormTextField(
              textInputAction: TextInputAction.done,
              label: 'Password'.toUpperCase(),
              textFieldType: TextFieldType.PASSWORD, validator: (value) {  },
            ),
            16.height,
            Text('Preferences'.toUpperCase(), style: boldTextStyle(color: jcbGreyColor, size: 14)),
            6.height,
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(border: Border.all(color: jcbSecBorderColor), borderRadius: radius(jcbButtonRadius)),
              width: context.width() - 32,
              child: Column(
                children: [
                  Row(
                    children: [
                      Text('receive receipt emails'.toUpperCase(), style: boldTextStyle(color: appStore.isDarkModeOn ? Colors.white : jcbDarkColor)),
                      Container(
                        width: 60,
                        decoration: BoxDecoration(color: isPref ? jcbPrimaryColor : jcbGreyColor, borderRadius: radius(50)),
                        child: Align(
                          alignment: isPref ? Alignment.topRight : Alignment.topLeft,
                          child: Icon(isPref ? Icons.check_circle : Icons.circle, color: Colors.white, size: 30),
                        ),
                      ).onTap(
                        () {
                          isPref = !isPref;
                          setState(() {});
                        },
                        splashColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                      )
                    ],
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  ),
                  16.height,
                  Text(
                    'Stay up to date with our new and cool promos and receive a more personalized experience.',
                    style: secondaryTextStyle(color: jcbGreyColor),
                  ),
                ],
              ),
            ),
             16.height,
           Center(child: Text('Social Network'.toUpperCase(), style: boldTextStyle(color: Colors.black, size: 16)),
            ),
            16.height,
            16.height,
            AppButton(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              width: context.width() - 32,
              child: SignInButton(
                        Buttons.Google,
                        text: "Sign in with Google",
                        onPressed: () async{
                          await _googleSignUp().then(
                                (value) => Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => JCBSuggestedRidesScreen(),
                              ),
                            ),
                          );
                        },
                      ),
              
             
            ),
            20.height,
            AppButton(
              padding: EdgeInsets.symmetric(horizontal: 4),
              width: context.width() - 32,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                //  Image.asset('images/juberCarBooking/fb_logo.png', height: 50, width: 50, fit: BoxFit.cover),
                  Text('Submit', style: boldTextStyle(color: Colors.white)),
                  SizedBox(width: 5),
                ],
              ),
              onTap: () {
                finish(context);
             
              },
              color: Color.fromARGB(255, 178, 66, 66),
              shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
              elevation: 0,
            ),
            
          ],
        ),
      ),
    );
  }
}
