import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:juber_car_booking/models/JCBCommonModel.dart';

import 'package:juber_car_booking/screens/JCBSuggestedRidesScreen.dart';
import 'package:nb_utils/nb_utils.dart';

import 'package:juber_car_booking/models/JCBSearchDestinationModel.dart';
import 'package:juber_car_booking/screens/JCBChooseDestinationScreen.dart';

import 'package:juber_car_booking/utils/JBCColors.dart';
import 'package:juber_car_booking/utils/JCBCommon.dart';
import 'package:juber_car_booking/utils/JCBConstants.dart';
import 'package:juber_car_booking/main.dart';


// ignore: must_be_immutable
class JCBSearchDestinationScreen extends StatefulWidget {
  @override
  State<JCBSearchDestinationScreen> createState() => _JCBSearchDestinationScreenState();
}

class _JCBSearchDestinationScreenState extends State<JCBSearchDestinationScreen> {
  bool _isProcessing = false;
  List<JCBSearchDestinationModel> destinationList = jcbDestinationsList();
  List<JCBCommonModel> pickList = jcbPickTimeSelection();

  TextEditingController destination = TextEditingController();
  List<String> addedDestinations = [];
   final _dropdownFormKey = GlobalKey<FormState>();

 TextEditingController _seatsOfPassenger = TextEditingController();
List<String> dropdownItems = ['1', '2', '3', '4'];
int selectedIndex = 1;
String? selectedValue = null;
 

// Declaration of Save user data in firebase


  final TextEditingController _currentLocation = TextEditingController();
  final TextEditingController _destinationLocation = TextEditingController();
 
  final TextEditingController _timeInput = TextEditingController();
  final TextEditingController _dateInput = TextEditingController();

  void _saveUserData() {
    String currentLocation = _currentLocation.text;
    String destinationLocation = _destinationLocation.text;
    int seatsOfPassenger = int.tryParse(_seatsOfPassenger.text) ?? 0;
    String timeInput = _timeInput.text;
    String dateInput = _dateInput.text;

    // Create a data object with the retrieved data
    Map<String, dynamic> userData = {
      'currentLocation': currentLocation,
      'destinationLocation': destinationLocation,
      'seatsOfPassenger': seatsOfPassenger,
      'timeInput': timeInput,
      'dateInput': dateInput,
    };

  
  // Get a reference to the "ridebooking" table under the "passengers" table
  DatabaseReference rideBookingRef = usersRef.child("ridebooking");

  // Save the user data to the "ridebooking" table
  rideBookingRef.push().set(userData);

    // Clear the text fields
    _currentLocation.clear();
    _destinationLocation.clear();
    _seatsOfPassenger.clear();
    _timeInput.clear();
    _dateInput.clear();
  }




  bool showAdd = false;

  Widget getDesWidget() {
    if (addedDestinations.isEmpty) {
      return Offstage();
    } else {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: addedDestinations.map((e) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(e, style: boldTextStyle()),
                  Icon(Icons.cancel, color: jcbSecBorderColor, size: 20).onTap(() {
                    addedDestinations.remove(e);
                    setState(() {});
                  }),
                ],
              ),
              Divider(color: jcbSecBorderColor),
            ],
          );
        }).toList(),
      );
    }
  }

  Widget getDottedLine() {
    if (addedDestinations.isEmpty) {
      return Offstage();
    } else {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: addedDestinations.map((e) {
          return Column(
            children: [
              Icon(Icons.square, color: jcbPrimaryColor, size: 16),
              jcbDottedLineComponent(height: 22),
            ],
          );
        }).toList(),
      );
    }
  }

  @override
  void dispose() {
    addedDestinations.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Image.asset(
            'images/juberCarBooking/jcbIcons/ic_close.png',
            height: 20,
            width: 20,
            fit: BoxFit.cover,
            color: context.iconColor,
          ),
          onPressed: () {
            finish(context);
          },
        ),
        actions: [
          IconButton(
            onPressed: () {
              JCBChooseDestinationScreen().launch(context);
            },
            icon: Icon(Icons.map_outlined, color: context.iconColor, size: 26),
          ),
        ],
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: context.scaffoldBackgroundColor,
                borderRadius: radiusOnly(bottomLeft: jcbBottomSheetRadius, bottomRight: jcbBottomSheetRadius),
                boxShadow: [
                  BoxShadow(
                    color: appStore.isDarkModeOn ? context.cardColor : Colors.grey,
                    offset: Offset(0.0, 1.0), //(x,y)
                    blurRadius: 6.0,
                  ),
                ],
              ),
              child: Row(
                children: [
                  Column(
                    children: [
                      Icon(Icons.circle, color: context.iconColor, size: 14),
                      jcbDottedLineComponent(height: 22),
                      getDottedLine(),
                      Icon(Icons.square, color: jcbPrimaryColor, size: 16),
                    ],
                  ),
                  8.width,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Text('Current Location', style: boldTextStyle()),
                      // Divider(color: jcbSecBorderColor),
                      AppTextField(
                        controller: _currentLocation,
                        textFieldType: TextFieldType.NAME,
                        textStyle: boldTextStyle(),
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: 'Current Location',
                          hintStyle: boldTextStyle(color: jcbGreyColor),
                          contentPadding: EdgeInsets.all(0),
                          isDense: true,
                          suffixIconConstraints: BoxConstraints(maxWidth: 40, maxHeight: 40),
                        ),
                        onChanged: (val) {
                          showAdd = true;
                          setState(() {});
                        },
                      ),
                      10.height,
                     // getDesWidget(),
                      AppTextField(
                        controller: _destinationLocation,
                        textFieldType: TextFieldType.NAME,
                        textStyle: boldTextStyle(),
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: 'Enter Destination',
                          hintStyle: boldTextStyle(color: jcbGreyColor),
                          contentPadding: EdgeInsets.all(0),
                          isDense: true,
                          suffixIcon: Icon(Icons.add, color: context.iconColor, size: 24).onTap(() {
                            if (destination.text != '') {
                              addedDestinations.add(destination.text);
                            } else {
                              toast('Please Enter Destination');
                            }
                            setState(() {});
                            destination.clear();
                          }),
                          suffixIconConstraints: BoxConstraints(maxWidth: 40, maxHeight: 40),
                        ),
                        onChanged: (val) {
                          showAdd = true;
                          setState(() {});
                        },
                      ),
                    ],
                  ).expand(),
                ],
              ),
            ),
              Container(
                        
                     padding: EdgeInsets.only(left: 10,
                     right: 10,
                     top: 20
                     ), 
                        child:    
       
                             Form(
                              
        key: _dropdownFormKey,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            

DropdownButtonFormField<String>(
  decoration: InputDecoration(
    enabledBorder: OutlineInputBorder(
      borderSide: BorderSide(color: Color.fromARGB(255, 213, 218, 222), width: 2),
      borderRadius: BorderRadius.circular(20),
    ),
    border: OutlineInputBorder(
      borderSide: BorderSide(color: Color.fromARGB(255, 227, 231, 235), width: 2),
      borderRadius: BorderRadius.circular(20),
    ),
    labelText: 'Select No of Seats',
    labelStyle: TextStyle(
      color: Colors.black,
      fontSize: 16,
    ),
    fillColor: Color.fromARGB(255, 28, 91, 154),
  ),
  dropdownColor: Color.fromARGB(255, 186, 179, 36),
  value: _seatsOfPassenger.text.isNotEmpty ? _seatsOfPassenger.text : null,
  onChanged: (String? newValue) {
    setState(() {
      selectedValue = newValue;
      _seatsOfPassenger.text = newValue ?? '';
    });
  },
  items: dropdownItems.map((String value) {
    return DropdownMenuItem<String>(
      value: value,
      child: Text(value),
    );
  }).toList(),
),
         
          ],
        ))  
               ),
              
       // 16.height,
        Column(
          mainAxisSize: MainAxisSize.min,
          children: pickList.map((e) {
            int index = pickList.indexOf(e);
            return Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: selectedIndex == index
                      ? jcbPrimaryColor.withAlpha(30)
                      : appStore.isDarkModeOn
                          ? context.cardColor
                          : jcbBackGroundColor,
                  borderRadius: radius(jcbButtonRadius),
                  border: Border.all(color: selectedIndex == index ? jcbPrimaryColor : jcbBackGroundColor)),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(e.title.validate(), style: boldTextStyle(color: appStore.isDarkModeOn ? Colors.white : jcbDarkColor)),
                      Text(e.subTitle.validate(), style: secondaryTextStyle(color: jcbGreyColor, size: 12)),
                    ],
                  ).expand(),
                  Checkbox(
                    value: selectedIndex == index,
                    onChanged: (bool? value) {
                      selectedIndex = index;
                      setState(() {});
                    },
                    activeColor: jcbPrimaryColor,
                  )
                ],
              ),
            ).paddingSymmetric(vertical: 6).onTap(() {
              selectedIndex = index;
              setState(() {});
            }, borderRadius: radius(jcbButtonRadius));
          }).toList(),
        ),
        16.height,
        // Staring of datepikc and time
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
                                 Container(
                            decoration: BoxDecoration(
     color: Color.fromARGB(255, 97, 119, 208),

                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30.0),
                    bottomLeft: Radius.circular(30.0),
                    bottomRight: Radius.circular(30.0),
                      topRight: Radius.circular(30.0)
                    )
                    ),
                        //margin: EdgeInsets.only(left: 10,right: 10),
                        child: 
                      TextField(
                controller: _timeInput, //editing controller of this TextField
                decoration: InputDecoration( 
                   icon: Icon(Icons.timer,
                   color: Colors.amber,), //icon of text field
                   labelText: "Set Time",labelStyle: TextStyle(color: Colors.white,
                   fontSize: 18
                   
                   )
                    //label text of field
                ),
                readOnly: true,  //set it true, so that user will not able to edit text
                onTap: () async {
                  TimeOfDay? pickedTime =  await showTimePicker(
                          initialTime: TimeOfDay.now(),
                          context: context,
                      );
                  
                  if(pickedTime != null ){
                      print(pickedTime.format(context));   //output 10:51 PM
                      DateTime parsedTime = DateFormat.jm().parse(pickedTime.format(context).toString());
                      //converting to DateTime so that we can further format on different pattern.
                      print(parsedTime); //output 1970-01-01 22:53:00.000
                      String formattedTime = DateFormat('HH:mm:ss').format(parsedTime);
                      print(formattedTime); //output 14:59:00
                      //DateFormat() is from intl package, you can format the time on any pattern you need.

                      setState(() {
                        _timeInput.text = formattedTime; //set the value of text field. 
                      });
                  }else{
                      print("Time is not selected");
                  }
                },
             )
          ),
             Container(
                            decoration: BoxDecoration(
  color: Color.fromARGB(255, 97, 119, 208),
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30.0),
                    bottomLeft: Radius.circular(30.0),
                    bottomRight: Radius.circular(30.0),
                      topRight: Radius.circular(30.0)
                    )
                    ),
                        margin: EdgeInsets.only(top: 15,),
                        child: 
                      TextField(
                     
                controller: _dateInput, //editing controller of this TextField
                decoration: InputDecoration( 
                   icon: Icon(Icons.calendar_today,
                   color: Colors.amber,), //icon of text field
                   labelText: "Enter Date",labelStyle: TextStyle(color: Colors.white,
                   fontSize: 18
                   
                   )
                    //label text of field
                ),
                readOnly: true,  //set it true, so that user will not able to edit text
                onTap: () async {
                  DateTime? pickedDate = await showDatePicker(
                      context: context, initialDate: DateTime.now(),
                      firstDate: DateTime(2000), //DateTime.now() - not to allow to choose before today.
                      lastDate: DateTime(2101)
                  );
                  
                  if(pickedDate != null ){
                      print(pickedDate);  //pickedDate output format => 2021-03-10 00:00:00.000
                      String formattedDate = DateFormat('yyyy-MM-dd').format(pickedDate); 
                      print(formattedDate); //formatted date output using intl package =>  2021-03-16
                        //you can implement different kind of Date Format here according to your requirement

                      setState(() {
                         _dateInput.text = formattedDate; //set output date to TextField value. 
                      });
                  }else{
                      print("Date is not selected");
                  }
                },
             )
          ),  
          ],
        ).visible(selectedIndex == 1),
        16.height,
         16.height,
          _isProcessing
                            ? CircularProgressIndicator()
                            :
        AppButton(
          width: context.width() - 32,
          child: Text('Search Drivers'.toUpperCase(), style: boldTextStyle(color: Colors.white)),
          onTap: () {
//            finish(context);
            
if (!_currentLocation.text.isNotEmpty)
    {

 displayToastMessage("Please enter Location", context);
    }
    
    else if (!_destinationLocation.text.isNotEmpty)
    {

 displayToastMessage("Please Enter Destination Location", context);
    }

     else if (!_timeInput.text.isNotEmpty)
    {

 displayToastMessage("Please Enter Time for Ride", context);
    }
    
    else if (!_dateInput.text.isNotEmpty)
    {

 displayToastMessage("Please Enter Date for Ride", context);
    }
        
    else

    {
                  _saveUserData();
JCBSuggestedRidesScreen().launch(context);

   }        

          },
          color: jcbPrimaryColor,
          shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
          elevation: 0,
        ),
                 
            // Container(
            //   decoration: BoxDecoration(
            //     border: Border(bottom: BorderSide(color: appStore.isDarkModeOn ? context.dividerColor : jcbSecBorderColor)),
            //   ),
            //   padding: EdgeInsets.all(16),
            //   child: Column(
            //     children: [
                 
            //     ],
            //   ),
            // ).onTap(() {
            //   JCBFavouriteScreen().launch(context);
            // }, splashColor: Colors.transparent, highlightColor: Colors.transparent),
            // Divider(thickness: 10, height: 10, color: appStore.isDarkModeOn ? context.cardColor : jcbBackGroundColor),
            // ListView.builder(
            //   physics: NeverScrollableScrollPhysics(),
            //   padding: EdgeInsets.all(16),
            //   shrinkWrap: true,
            //   itemCount: destinationList.length,
            //   itemBuilder: (context, index) {
            //     return JCBDestinationWidget(destination: destinationList[index]).onTap(
            //       () {
            //         JCBChooseDestinationScreen(destination: destinationList[index].name).launch(context);
            //       },
            //       splashColor: Colors.transparent,
            //       highlightColor: Colors.transparent,
            //     );
            //   },
            // ),
          ],
        ),
      ),
    );
  }
}



displayToastMessage(String message, BuildContext context)
{
  Fluttertoast.showToast(msg: message,
backgroundColor: Colors.red,

  );

}