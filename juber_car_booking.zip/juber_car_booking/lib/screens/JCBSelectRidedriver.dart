import 'package:flutter/material.dart';
import 'package:juber_car_booking/models/JCBRiderRequestdetails.dart';

import 'package:nb_utils/nb_utils.dart';

import 'package:juber_car_booking/utils/JBCColors.dart';

import 'package:juber_car_booking/components/JCBRiderequestpersons.dart';

class JCBSelectRidedriver extends StatefulWidget {
  const JCBSelectRidedriver({Key? key}) : super(key: key);

  @override
  State<JCBSelectRidedriver> createState() => _JCBSelectRidedriverState();
}

class _JCBSelectRidedriverState extends State<JCBSelectRidedriver> {
   List<JCBRideRequestModel> rideList = getRiderequestTypes();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
     appBar: AppBar(
        leading: IconButton(
          icon: Image.asset(
            'images/juberCarBooking/jcbIcons/ic_close.png',
            height: 20,
            width: 20,
            fit: BoxFit.cover,
            color: Colors.red,
          ),
          onPressed: () {
            finish(context);
          },
        ),
      
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
          JCBRideRequestComponent(requestlist:getRiderequestTypes()),
            Divider(color: jcbSecBorderColor),
        
        ]),
          ),
    );
  }
}
