import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:juber_car_booking/firebase_auth/validator.dart';
import 'package:juber_car_booking/screens/JCBHomeScreen.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:juber_car_booking/screens/JCBLoginScreen.dart';

import 'package:juber_car_booking/main.dart';

class JCBSignUpScreen extends StatefulWidget {
  @override
  State<JCBSignUpScreen> createState() => _JCBSignUpScreenState();
}

class _JCBSignUpScreenState extends State<JCBSignUpScreen> {
  final _registerFormKey = GlobalKey<FormState>();
  bool _isProcessing = false;
  final _emailTextController = TextEditingController();
  final _passwordTextController = TextEditingController();
  final _name = TextEditingController();

  final _focusName = FocusNode();
  final _focusEmail = FocusNode();
  final _focusPassword = FocusNode();

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  void registerNewUser(BuildContext context) async {
    setState(() {
      _isProcessing = true; // Set isLoading to true before starting registration
    });

    try {
      if (_emailTextController.text.isEmpty || _passwordTextController.text.isEmpty) {
        displayToastMessage("Please enter email and password", context);
        return;
      }

      final firebaseUser = (await _firebaseAuth.createUserWithEmailAndPassword(
        email: _emailTextController.text,
        password: _passwordTextController.text,
      )).user;

      if (firebaseUser != null) {
        // Generate a unique driver ID
        String userId = firebaseUser.uid;

        Map<String, dynamic> userDataMap = {
          "name": _name.text.trim(),
          "email": _emailTextController.text.trim(),
          "password": _passwordTextController.text.trim(),
        };

        // Save the passenger data under the "drivers" node with the driver ID as the key
        usersRef.child("user_id").child(userId).set(userDataMap);

        displayToastMessage("User created successfully", context);
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (context) => JCBHomeScreen(),
          ),
        );
      } else {
        displayToastMessage("User creation failed", context);
      }
    } catch (errMsg) {
      displayToastMessage("User creation failed", context);
    } finally {
      setState(() {
        _isProcessing = false; // Set isLoading to false after registration completion
      });
    }
  }

  displayToastMessage(String message, BuildContext context) {
    Fluttertoast.showToast(
      msg: message,
      backgroundColor: Colors.red,
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        _focusName.unfocus();
        _focusEmail.unfocus();
        _focusPassword.unfocus();
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.redAccent,
          title: Text('Create Account'),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 120,
                    width: 120,
                    child: Image.asset("images/juberCarBooking/final.png"),
                  ),
                  Form(
                    key: _registerFormKey,
                    child: Column(
                      children: <Widget>[
                        TextFormField(
                          controller: _name,
                          focusNode: _focusName,
                          validator: (value) => Validator.validateName(
                            name: value,
                          ),
                          decoration: InputDecoration(
                            hintText: "Name",
                            errorBorder: UnderlineInputBorder(
                              borderRadius: BorderRadius.circular(6.0),
                              borderSide: BorderSide(
                                color: Colors.red,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 12.0),
                        TextFormField(
                          controller: _emailTextController,
                          focusNode: _focusEmail,
                          validator: (value) => Validator.validateEmail(
                            email: value,
                          ),
                          decoration: InputDecoration(
                            hintText: "Email",
                            errorBorder: UnderlineInputBorder(
                              borderRadius: BorderRadius.circular(6.0),
                              borderSide: BorderSide(
                                color: Colors.red,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 12.0),
                        TextFormField(
                          controller: _passwordTextController,
                          focusNode: _focusPassword,
                          obscureText: true,
                          validator: (value) => Validator.validatePassword(
                            password: value,
                          ),
                          decoration: InputDecoration(
                            hintText: "Password",
                            errorBorder: UnderlineInputBorder(
                              borderRadius: BorderRadius.circular(6.0),
                              borderSide: BorderSide(
                                color: Colors.red,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 32.0),
                        _isProcessing
                            ? CircularProgressIndicator()
                            : Row(
                                children: [
                                  Expanded(
                                    child: ElevatedButton(
                                      onPressed: () {
                                        registerNewUser(context);
                                      },
                                      child: Text(
                                        'Sign up',
                                        style: TextStyle(color: Colors.white, fontSize: 17),
                                      ),
                                      style: ButtonStyle(
                                        backgroundColor: MaterialStateProperty.all(Colors.red),
                                      ),
                                    ),
                                  ),
                                ],
                              )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
