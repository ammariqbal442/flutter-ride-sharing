import 'package:flutter/material.dart';
import 'package:juber_car_booking/admin-panel/models/JCBSearchDestinationModel.dart';
import 'package:juber_car_booking/screens/JCBPaymentMethodScreen.dart';
import 'package:nb_utils/nb_utils.dart';

import 'package:juber_car_booking/components/JCBRideTypeComponent.dart';
import 'package:juber_car_booking/models/JCBRideModel.dart';
import 'package:juber_car_booking/utils/JBCColors.dart';
import 'package:juber_car_booking/utils/JCBConstants.dart';
import 'package:juber_car_booking/main.dart';

import 'JCBSearchDestinationScreen.dart';

class JCBSuggestedRidesScreen extends StatefulWidget {
  const JCBSuggestedRidesScreen({Key? key}) : super(key: key);

  @override
  State<JCBSuggestedRidesScreen> createState() => _JCBSuggestedRidesScreenState();
}

class _JCBSuggestedRidesScreenState extends State<JCBSuggestedRidesScreen> {
  List<JCBRideModel> rideList = getRideTypes();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: 
    AppBar(
        leading: IconButton(
          icon: Image.asset(
            'images/juberCarBooking/jcbIcons/ic_close.png',
            height: 20,
            width: 20,
            fit: BoxFit.cover,
            color: context.iconColor,
          ),
          onPressed: () {
              JCBSearchDestinationScreen().launch(context);
          },
        ),
       
        elevation: 0,
      ),
      body: SingleChildScrollView(

        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
          
            Text(
              'Available RIDES',
              style:
                  boldTextStyle(size: 20, fontFamily: jcbFont, color: appStore.isDarkModeOn ? Colors.white : jcbDarkColor, weight: FontWeight.w900),
            ),
            8.height,
            JCBRideComponent(rideList: rideList),
            Divider(color: jcbSecBorderColor),
            16.height,
          ],
        ),
      ).paddingTop(context.statusBarHeight),
      bottomNavigationBar: AppButton(
        child: Text('Book Now'.toUpperCase(), style: boldTextStyle(color: Colors.white)),
        onTap: () {
          showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              enableDrag: true,
              isDismissible: true,
              shape: RoundedRectangleBorder(borderRadius: radiusOnly(topLeft: 30, topRight: 30)),
              builder: (context) {
                return JCBPaymentMethodScreen();
              });
        },
        color: jcbPrimaryColor,
        elevation: 0,
        shapeBorder: RoundedRectangleBorder(borderRadius: radius(jcbButtonRadius)),
      ).paddingOnly(left: 16, right: 16, bottom: 16),
    );
  }
}
