class Globals {
  static String userName = '';
}