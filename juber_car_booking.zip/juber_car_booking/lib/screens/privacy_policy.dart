import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// ignore: use_key_in_widget_constructors
class PrivacyPolicy extends StatefulWidget {
  static  String idscreen ="privacypolicy";
 

  @override
  State<PrivacyPolicy> createState() => _PrivacyPolicyState();
}

class _PrivacyPolicyState extends State<PrivacyPolicy> {
  @override
  Widget build(BuildContext context) {
    return
     Scaffold(appBar: AppBar(
   backgroundColor: Color.fromARGB(255, 175, 53, 26),
       title: Text("Privacy Policy",

style:  GoogleFonts.lato(fontStyle: FontStyle.normal),
            ),

     ),
     
     body: SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Column(children: <Widget>[

Container(

  margin: EdgeInsets.only(top: 30,right: 250),
  child: 

Text("Introduction:",

style:  GoogleFonts.lato(fontStyle: FontStyle.normal,

fontSize: 18,
fontWeight: FontWeight.bold,
color: Colors.black),

)
),



Container(

  margin: EdgeInsets.only(top: 30,left: 10),
  child: 

Text("When you use Uber, you trust us with your personal data. We’re committed to keeping that trust. That starts with helping you understand our privacy practices.This notice describes the personal data (“data”) we collect, how it’s used and shared, and your choices regarding this data. We recommend that you read this along with our privacy overview, which highlights key points about our privacy practices.",

style:  GoogleFonts.lato(fontStyle: FontStyle.normal,

fontSize: 15,

color: Colors.black),

)
),

Container(

  margin: EdgeInsets.only(top: 30,right: 265),
  child: 

Text("Overview:",

style:  GoogleFonts.lato(fontStyle: FontStyle.normal,

fontSize: 18,
fontWeight: FontWeight.bold,
color: Colors.black),

)
),


Container(

  margin: EdgeInsets.only(top: 10,left: 10),
  child: 

Text("This notice applies to users of Uber’s services anywhere in the world, including users of Uber’s apps, websites, features, or other services. This notice describes how Uber and its affiliates collect and use data. This notice applies to all Uber users globally, unless they use a service covered by a separate privacy notice, such as Uber Freight or Careem. This notice specifically applies to: Riders: individuals who request or receive transportation and related services via their Uber account. Drivers: individuals who provide transportation to Riders individually or through partner transportation companies. Order recipients: individuals who request or receive food or other products and services for delivery or pick-up via their Uber Eats, Cornershop or Postmates account. This includes individuals who use guest checkout features to access delivery or pick-up services without creating and/or logging into their account. Delivery persons: individuals who provide delivery services via Uber Eats, Cornershop or Postmates.  Guest Users: individuals who receive ride and delivery services ordered by other Uber account owners, including those who receive services arranged by Uber Health, Uber Central, Uber Direct or Uber for Business customers (collectively, “Enterprise Customers”), or by friends, family members or other individual account owners. This notice also governs Uber’s other collections of data in connection with its services. For example, we may collect the contact information of owners or employees of restaurants or other merchants on the Uber Eats, Cornershop or Postmates platforms; the contact information of individuals that manage and use accounts owned by Enterprise Customers; or data of individuals who start but do not complete their applications to be drivers or delivery persons. All those subject to this notice are referred to as “users” in this notice. Our privacy practices are subject to applicable laws in the places in which we operate. This means that we engage in the practices described in this notice in a particular country or region only if permitted under the laws of those places. In addition, please note the following: For users in Argentina: The Public Information Access agency, in its role of Regulating Body of Law 25.326, is responsible for receiving complaints and reports presented by any data subjects who believe their rights have been impacted by a violation of the local data protection regulation. For users in Brazil: Please see here for information regarding Uber’s privacy practices required under Brazil’s General Data Protection Law (Lei Geral de Proteção de Dados - LGPD). For users in the United States : Information regarding Uber’s privacy practices required under U.S. state privacy laws, including the California Consumer Privacy Act), is available here. For users in Colombia and Jamaica: “Riders” and “drivers” as defined in this Notice are known respectively as “lessors” and “lessees” in Colombia and Jamaica. For users in Mexico: Please see here for information regarding Uber’s privacy practices required under Mexico’s Personal Data Protection Law (Ley Federal de Protección de Datos Personales en Posesión de los Particulares). For users in Nigeria: Uber processes the data of users in Nigeria on the grounds that it is necessary to fulfill the terms of our agreements with those users, or based on their consent. For users in South Korea: Please see here for information about Uber affiliate UT LLC's privacy practices.Please contact us here or through the addresses below with any questions regarding our practices in a particular country or region.",

style:  GoogleFonts.lato(fontStyle: FontStyle.normal,

fontSize: 15,

color: Colors.black),

)
),

      ],),
     ),
     );
    }
}